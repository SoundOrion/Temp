﻿using Orleans;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

public interface IChatGrain : IGrainWithStringKey
{
    Task SendMessage(string user, string message);
}

public class ChatGrain : Grain, IChatGrain
{
    private readonly IHubContext<ChatHub> _hubContext;

    public ChatGrain(IHubContext<ChatHub> hubContext)
    {
        _hubContext = hubContext;
    }

    public async Task SendMessage(string user, string message)
    {
        await _hubContext.Clients.All.SendAsync("ReceiveMessage", user, message);
    }
}
