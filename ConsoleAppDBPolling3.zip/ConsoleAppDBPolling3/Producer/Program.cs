﻿using System;
using System.Collections.Concurrent;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static BlockingCollection<(int, string)> queue = new BlockingCollection<(int, string)>();

    static async Task Main()
    {
        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int pollingInterval = 60000; // 60秒ごとにポーリング

        Task producerTask = Task.Run(() => Producer(connectionString, tableName, pollingInterval));
        Task consumerTask = Task.Run(() => Consumer());

        await Task.WhenAll(producerTask, consumerTask);
    }

    static async Task Producer(string connectionString, string tableName, int pollingInterval)
    {
        while (true)
        {
            try
            {
                await CheckDatabaseAsync(connectionString, tableName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task CheckDatabaseAsync(string connectionString, string tableName)
    {
        string query = $"SELECT * FROM {tableName} WHERE Processed = 0";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int id = reader.GetInt32(0);
                        string content = reader.GetString(1);

                        queue.Add((id, content));

                        // レコードを処理済みに更新
                        await MarkRecordAsProcessedAsync(connectionString, tableName, id);
                    }
                }
            }
        }
    }

    private static async Task MarkRecordAsProcessedAsync(string connectionString, string tableName, int id)
    {
        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                await command.ExecuteNonQueryAsync();
            }
        }
    }

    static void Consumer()
    {
        foreach (var (id, content) in queue.GetConsumingEnumerable())
        {
            ProcessRecord(id, content);
        }
    }

    private static void ProcessRecord(int id, string content)
    {
        // ここにレコードの内容に応じた処理を実装
        if (content.Contains("example keyword"))
        {
            Console.WriteLine($"ID={id}: キーワードが含まれています。処理を行います。");
            // 処理の実装
        }
        else
        {
            Console.WriteLine($"ID={id}: キーワードは含まれていません。");
        }
    }
}
