﻿namespace BlazorServerAuthenticationAndAuthorization;

using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Threading.Tasks;

/// <summary>
/// カスタムミドルウェアを使用して画像のリクエストをハンドルする方法
/// </summary>
public class ImageRequestHandlerMiddleware
{
    private readonly RequestDelegate _next;

    public ImageRequestHandlerMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        // リクエストが画像に対するものかをチェック
        if (IsImageRequest(context.Request.Path))
        {
            // 画像のリクエストを処理するメソッドを呼び出す
            await HandleImageRequestAsync(context);
            return;
        }

        // 画像へのアクセスではない場合は次のミドルウェアに処理を移す
        await _next(context);
    }

    private bool IsImageRequest(PathString path)
    {
        string extension = Path.GetExtension(path);
        if (!string.IsNullOrEmpty(extension))
        {
            // ここでは簡単な拡張子のチェックを行います。
            // 必要に応じて、より厳密なチェックを行うことができます。
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
            return Array.IndexOf(imageExtensions, extension.ToLower()) != -1;
        }
        return false;
    }

    private async Task HandleImageRequestAsync(HttpContext context)
    {
        // 画像へのアクセスを処理する
        // この例では、特定のロジックを実装していますが、必要に応じてカスタマイズしてください。
        // 例えば、認証/認可のチェックを行ったり、画像を提供するなどが考えられます。
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        await context.Response.WriteAsync("Access to images is forbidden.");
    }
}

