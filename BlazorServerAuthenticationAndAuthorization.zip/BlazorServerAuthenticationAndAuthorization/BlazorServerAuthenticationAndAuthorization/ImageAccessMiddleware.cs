﻿namespace BlazorServerAuthenticationAndAuthorization;

using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

/// <summary>
/// ミドルウェアを使用して認証と認可を行う方法
/// </summary>
public class ImageAccessMiddleware
{
    private readonly RequestDelegate _next;

    public ImageAccessMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        // リクエストが画像に対するものかをチェック
        if (context.Request.Path.StartsWithSegments("/images"))
        {
            // ここに認証/認可のロジックを実装する
            // 例えば、認証済みでないユーザーに対しては403 Forbiddenを返す

            // ここでは、簡単な例として、認証済みのユーザーのみが画像にアクセスできると仮定
            if (!context.User.Identity.IsAuthenticated)
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                return;
            }
        }

        // 画像へのアクセスではない場合は次のミドルウェアに処理を移す
        await _next(context);
    }
}
