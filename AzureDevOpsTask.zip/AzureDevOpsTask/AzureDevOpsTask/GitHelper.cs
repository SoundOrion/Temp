﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LibGit2Sharp;

namespace AzureDevOpsTask;

public static class GitHelper
{
    public static Task<IEnumerable<string>> GetChangedFiles(string targetBranch)
    {
        return Task.Run(() =>
        {
            var repoPath = Environment.GetEnvironmentVariable("System.DefaultWorkingDirectory");
            var changedFiles = new List<string>();

            using (var repo = new Repository(repoPath))
            {
                var filter = new CommitFilter { IncludeReachableFrom = targetBranch, ExcludeReachableFrom = repo.Head.Tip };
                foreach (var commit in repo.Commits.QueryBy(filter))
                {
                    foreach (var parent in commit.Parents)
                    {
                        var patch = repo.Diff.Compare<Patch>(parent.Tree, commit.Tree);
                        foreach (var entry in patch)
                        {
                            if (!BinaryExtensions.Contains(GetFileExtension(entry.Path)))
                            {
                                changedFiles.Add(entry.Path);
                            }
                        }
                    }
                }
            }

            Console.WriteLine($"Changed Files (excluding binary files): \n {string.Join('\n', changedFiles)}");

            return changedFiles.AsEnumerable();
        });
    }

    public static Task<string> GetDiff(string targetBranch, string fileName)
    {
        return Task.Run(() =>
        {
            var repoPath = Environment.GetEnvironmentVariable("System.DefaultWorkingDirectory");

            using (var repo = new Repository(repoPath))
            {
                var targetCommit = repo.Branches[targetBranch].Commits.First();
                var headCommit = repo.Head.Tip;

                var patch = repo.Diff.Compare<Patch>(targetCommit.Tree, headCommit.Tree, new[] { fileName });

                return patch.FirstOrDefault()?.Patch ?? string.Empty;
            }
        });
    }

    static string GetFileExtension(string fileName)
    {
        return fileName.Substring(fileName.LastIndexOf('.') + 1);
    }
}

//// Example BinaryExtensions class. Adjust based on your specific binary file extensions.
//public static class BinaryExtensions
//{
//    private static readonly HashSet<string> binaryExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
//    {
//        "exe", "dll", "bin", "jpg", "png", "gif", "zip", "tar", "gz", "rar"
//    };

//    public static bool Contains(string extension)
//    {
//        return binaryExtensions.Contains(extension);
//    }
//}


//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Linq;
//using System.Threading.Tasks;

//namespace AzureDevOpsTask;

//public static class GitHelper
//{
//    public static async Task<IEnumerable<string>> GetChangedFiles(string targetBranch)
//    {
//        var startInfo = new ProcessStartInfo
//        {
//            FileName = "git",
//            Arguments = $"diff {targetBranch} --name-only --diff-filter=AM",
//            RedirectStandardOutput = true,
//            UseShellExecute = false,
//            CreateNoWindow = true
//        };

//        using var process = new Process { StartInfo = startInfo };
//        process.Start();

//        var output = await process.StandardOutput.ReadToEndAsync();
//        await process.WaitForExitAsync();

//        var files = output.Split('\n').Where(line => !string.IsNullOrWhiteSpace(line));
//        var nonBinaryFiles = files.Where(file => !BinaryExtensions.Contains(GetFileExtension(file)));

//        Console.WriteLine($"Changed Files (excluding binary files): \n {string.Join('\n', nonBinaryFiles)}");

//        return nonBinaryFiles;
//    }

//    public static async Task<string> GetDiff(string targetBranch, string fileName)
//    {
//        var startInfo = new ProcessStartInfo
//        {
//            FileName = "git",
//            Arguments = $"diff {targetBranch} -- {fileName}",
//            RedirectStandardOutput = true,
//            UseShellExecute = false,
//            CreateNoWindow = true
//        };

//        using var process = new Process { StartInfo = startInfo };
//        process.Start();

//        var output = await process.StandardOutput.ReadToEndAsync();
//        await process.WaitForExitAsync();

//        return output;
//    }

//    static string GetFileExtension(string fileName)
//    {
//        return fileName.Substring(fileName.LastIndexOf('.') + 1);
//    }
//}
