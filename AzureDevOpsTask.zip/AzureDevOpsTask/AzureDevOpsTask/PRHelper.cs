﻿using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AzureDevOpsTask;

public static class PRHelper
{
    public static async Task AddCommentToPR(string fileName, string comment, HttpClient httpClient)
    {
        var body = new
        {
            comments = new[] { new { parentCommentId = 0, content = comment, commentType = 1 } },
            status = 1,
            threadContext = new { filePath = fileName }
        };

        var prUrl = $"{Environment.GetEnvironmentVariable("SYSTEM.TEAMFOUNDATIONCOLLECTIONURI")}{Environment.GetEnvironmentVariable("SYSTEM.TEAMPROJECTID")}/_apis/git/repositories/{Environment.GetEnvironmentVariable("Build.Repository.Name")}/pullRequests/{Environment.GetEnvironmentVariable("System.PullRequest.PullRequestId")}/threads?api-version=5.1";

        var response = await httpClient.PostAsync(prUrl, new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json"));
        response.EnsureSuccessStatusCode();

        Console.WriteLine("New comment added.");
    }

    public static async Task DeleteExistingComments(HttpClient httpClient)
    {
        Console.WriteLine("Start deleting existing comments added by the previous Job ...");

        var threadsUrl = $"{Environment.GetEnvironmentVariable("SYSTEM.TEAMFOUNDATIONCOLLECTIONURI")}{Environment.GetEnvironmentVariable("SYSTEM.TEAMPROJECTID")}/_apis/git/repositories/{Environment.GetEnvironmentVariable("Build.Repository.Name")}/pullRequests/{Environment.GetEnvironmentVariable("System.PullRequest.PullRequestId")}/threads?api-version=5.1";
        var threadsResponse = await httpClient.GetStringAsync(threadsUrl);
        var threads = JsonSerializer.Deserialize<ThreadResponse>(threadsResponse);

        var collectionUri = Environment.GetEnvironmentVariable("SYSTEM.TEAMFOUNDATIONCOLLECTIONURI");
        var collectionName = GetCollectionName(collectionUri);
        var buildServiceName = $"{Environment.GetEnvironmentVariable("SYSTEM.TEAMPROJECT")} Build Service ({collectionName})";

        foreach (var thread in threads.Value.Where(t => t.ThreadContext != null))
        {
            var commentsUrl = $"{Environment.GetEnvironmentVariable("SYSTEM.TEAMFOUNDATIONCOLLECTIONURI")}{Environment.GetEnvironmentVariable("SYSTEM.TEAMPROJECTID")}/_apis/git/repositories/{Environment.GetEnvironmentVariable("Build.Repository.Name")}/pullRequests/{Environment.GetEnvironmentVariable("System.PullRequest.PullRequestId")}/threads/{thread.Id}/comments?api-version=5.1";
            var commentsResponse = await httpClient.GetStringAsync(commentsUrl);
            var comments = JsonSerializer.Deserialize<CommentResponse>(commentsResponse);

            foreach (var comment in comments.Value.Where(c => c.Author.DisplayName == buildServiceName))
            {
                var removeCommentUrl = $"{Environment.GetEnvironmentVariable("SYSTEM.TEAMFOUNDATIONCOLLECTIONURI")}{Environment.GetEnvironmentVariable("SYSTEM.TEAMPROJECTID")}/_apis/git/repositories/{Environment.GetEnvironmentVariable("Build.Repository.Name")}/pullRequests/{Environment.GetEnvironmentVariable("System.PullRequest.PullRequestId")}/threads/{thread.Id}/comments/{comment.Id}?api-version=5.1";
                var deleteResponse = await httpClient.DeleteAsync(removeCommentUrl);
                deleteResponse.EnsureSuccessStatusCode();
            }
        }

        Console.WriteLine("Existing comments deleted.");
    }

    static string GetCollectionName(string collectionUri)
    {
        var collectionUriWithoutProtocol = collectionUri.Replace("https://", "").Replace("http://", "");

        return collectionUriWithoutProtocol.Contains(".visualstudio.")
            ? collectionUriWithoutProtocol.Split('.').First()
            : collectionUriWithoutProtocol.Split('/').Skip(1).First();
    }
}

public class ThreadResponse
{
    public Thread[] Value { get; set; }
}

public class Thread
{
    public int Id { get; set; }
    public ThreadContext ThreadContext { get; set; }
}

public class ThreadContext
{
    public string FilePath { get; set; }
}

public class CommentResponse
{
    public Comment[] Value { get; set; }
}

public class Comment
{
    public int Id { get; set; }
    public Author Author { get; set; }
}

public class Author
{
    public string DisplayName { get; set; }
}
