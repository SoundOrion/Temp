﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace AzureDevOpsTask;

class Program
{
    static async Task Main(string[] args)
    {
        try
        {
            var buildReason = Environment.GetEnvironmentVariable("Build.Reason");
            if (buildReason != "PullRequest")
            {
                Console.WriteLine("This task should be run only when the build is triggered from a Pull Request.");
                return;
            }

            var supportSelfSignedCertificate = bool.Parse(Environment.GetEnvironmentVariable("support_self_signed_certificate") ?? "false");
            var apiKey = Environment.GetEnvironmentVariable("api_key");
            var aoiEndpoint = Environment.GetEnvironmentVariable("aoi_endpoint");

            if (string.IsNullOrEmpty(apiKey))
            {
                Console.WriteLine("No Api Key provided!");
                return;
            }

            HttpClientHandler handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => supportSelfSignedCertificate || errors == System.Net.Security.SslPolicyErrors.None
            };

            using HttpClient httpClient = new HttpClient(handler);
            var targetBranch = GetTargetBranchName();

            if (string.IsNullOrEmpty(targetBranch))
            {
                Console.WriteLine("No target branch found!");
                return;
            }

            var fileNames = await GitHelper.GetChangedFiles(targetBranch);

            await PRHelper.DeleteExistingComments(httpClient);

            foreach (var fileName in fileNames)
            {
                await FileReviewer.ReviewFile(targetBranch, fileName, httpClient, apiKey, aoiEndpoint);
            }

            Console.WriteLine("Pull Request reviewed.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Task failed: {ex.Message}");
        }
    }

    static string GetTargetBranchName()
    {
        var targetBranchName = Environment.GetEnvironmentVariable("System.PullRequest.TargetBranchName");
        return targetBranchName ?? Environment.GetEnvironmentVariable("System.PullRequest.TargetBranch")?.Replace("refs/heads/", "");
    }
}
