﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AzureDevOpsTask;

public static class FileReviewer
{
    public static async Task ReviewFile(string targetBranch, string fileName, HttpClient httpClient, string apiKey, string aoiEndpoint)
    {
        Console.WriteLine($"Start reviewing {fileName} ...");

        var defaultOpenAIModel = "gpt-3.5-turbo";
        var patch = await GitHelper.GetDiff(targetBranch, fileName);

        var instructions = @"Act as a code reviewer of a Pull Request, providing feedback on possible bugs and clean code issues.
                You are provided with the Pull Request changes in a patch format.
                Each patch entry has the commit message in the Subject line followed by the code changes (diffs) in a unidiff format.

                As a code reviewer, your task is:
                    - Review only added, edited or deleted lines.
                    - If there's no bugs and the changes are correct, write only 'No feedback.'
                    - If there's bug or uncorrect code changes, don't write 'No feedback.'";

        try
        {
            var review = await GetReview(apiKey, aoiEndpoint, instructions, patch);

            if (!string.IsNullOrWhiteSpace(review) && review.Trim() != "No feedback.")
            {
                await PRHelper.AddCommentToPR(fileName, review, httpClient);
            }

            Console.WriteLine($"Review of {fileName} completed.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error reviewing file {fileName}: {ex.Message}");
        }
    }

    static async Task<string> GetReview(string apiKey, string aoiEndpoint, string instructions, string patch)
    {
        if (!string.IsNullOrEmpty(aoiEndpoint))
        {
            var requestBody = new
            {
                max_tokens = 500,
                messages = new[]
                {
                    new { role = "user", content = $"{instructions}\npatch: {patch}" }
                }
            };

            using var httpClient = new HttpClient();
            var response = await httpClient.PostAsync(aoiEndpoint, new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json"));
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();
            var choices = JsonSerializer.Deserialize<Response>(responseBody).Choices;

            return choices?.FirstOrDefault()?.Message?.Content;
        }

        throw new InvalidOperationException("No valid endpoint or OpenAI API key provided.");
    }

    public class Response
    {
        public Choice[] Choices { get; set; }
    }

    public class Choice
    {
        public Message Message { get; set; }
    }

    public class Message
    {
        public string Content { get; set; }
    }
}
