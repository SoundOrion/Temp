﻿using System.Collections.Generic;

namespace AzureDevOpsTask;

public static class BinaryExtensions
{
    public static HashSet<string> Extensions { get; } = new HashSet<string>
    {
        // Add binary extensions here
        "jpg", "png", "exe", "dll", // etc.
    };

    public static bool Contains(string extension)
    {
        return Extensions.Contains(extension.ToLower());
    }
}
