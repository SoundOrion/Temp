using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using GrainInterfaces;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Orleans.Serialization.Buffers;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Options;

public class Program
{
    private static BlockingCollection<List<(int, string)>> queue = new BlockingCollection<List<(int, string)>>();

    static async Task Main(string[] args)
    {
        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (sender, eventArgs) =>
        {
            eventArgs.Cancel = true;
            cts.Cancel();
        };

        using IHost host = Host.CreateDefaultBuilder(args)
    .UseOrleansClient(client =>
    {
        client.UseLocalhostClustering()
                .Configure<ClusterOptions>(options =>
                 {
                     options.ClusterId = "dev";
                     options.ServiceId = "OrleansSampleApp";
                 });
    })
    .ConfigureLogging(logging => logging.AddConsole())
    .UseConsoleLifetime()
    .Build();

        //   var builder = Host.CreateDefaultBuilder(args)
        //.ConfigureServices((context, services) =>
        //{
        //    services.AddHostedService<OrleansClientHostedService>();
        //    services.Configure<DatabaseOptions>(context.Configuration.GetSection("Database"));
        //})
        //.ConfigureLogging(logging => logging.AddConsole())
        //.UseConsoleLifetime();

        //using var host = builder.Build();

        await host.StartAsync();

        var client = host.Services.GetRequiredService<IClusterClient>();

        var producerTask = ProduceAsync(client, cts.Token);
        var consumerTask = ConsumeAsync(client, cts.Token);

        try
        {
            await Task.WhenAll(producerTask, consumerTask);
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("���삪�L�����Z������܂����B");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"�G���[���������܂���: {ex.Message}");
        }

        await host.StopAsync();
    }

    private static async Task<IClusterClient> StartClientAsync(string[] args)
    {
        using IHost host = Host.CreateDefaultBuilder(args)
    .UseOrleansClient(client =>
    {
        client.UseLocalhostClustering();
    })
    .ConfigureLogging(logging => logging.AddConsole())
    .UseConsoleLifetime()
    .Build();


        await host.StartAsync();

        var client = host.Services.GetRequiredService<IClusterClient>();

        return client;
    }

    private static async Task ProduceAsync(IClusterClient client, CancellationToken cancellationToken)
    {
        //var options = client.ServiceProvider.GetRequiredService<IOptions<DatabaseOptions>>().Value;
        //string connectionString = options.ConnectionString;
        //string tableName = options.TableName;
        //int batchSize = options.BatchSize; // �o�b�`�T�C�Y���w��
        //int pollingInterval = options.PollingInterval; // �|�[�����O�Ԋu

        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int batchSize = 1; // �o�b�`�T�C�Y���w��
        int pollingInterval = 2000; // 2�b���ƂɃ|�[�����O

        //while (!cancellationToken.IsCancellationRequested)
        while (!queue.IsAddingCompleted)
        {
            try
            {
                var batch = await CheckDatabaseAsync(connectionString, tableName, batchSize);
                if (batch.Count > 0)
                {
                    queue.Add(batch);
                    await MarkRecordsAsProcessedAsync(connectionString, tableName, batch);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"�f�[�^�x�[�X�̃`�F�b�N���ɃG���[���������܂���: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task ConsumeAsync(IClusterClient client, CancellationToken cancellationToken)
    {
        var processingGrain = client.GetGrain<IProcessingGrain>(Guid.NewGuid());

        //foreach (var batch in queue.GetConsumingEnumerable())
        //{
        //    await processingGrain.ProcessBatchAsync(batch);
        //}

        try
        {
            await foreach (var batch in GetConsumingAsyncEnumerable(queue, cancellationToken))
            {
                await processingGrain.ProcessBatchAsync(batch);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"�o�b�`�̏������ɃG���[���������܂���: {ex.Message}");
        }
    }

    /// <summary>
    /// �R���V���[�}�[�^�X�N��IAsyncEnumerable���g�p���āA�񓯊��ŃL���[����o�b�`�������悤
    /// </summary>
    /// <param name="queue"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    private static async IAsyncEnumerable<List<(int, string)>> GetConsumingAsyncEnumerable(BlockingCollection<List<(int, string)>> queue, [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        while (!queue.IsCompleted)
        {
            if (queue.TryTake(out var batch, Timeout.Infinite, cancellationToken))
            {
                yield return batch;
            }

            await Task.Yield(); // �񓯊��R���e�L�X�g�̕ێ�
        }
    }

    private static async Task<List<(int, string)>> CheckDatabaseAsync(string connectionString, string tableName, int batchSize)
    {
        string query = $"SELECT TOP (@BatchSize) * FROM {tableName} WHERE Processed = 0";

        //�_�~�[
        var batch = new List<(int, string)>();
        int id = int.Parse(DateTime.Today.ToOADate().ToString());
        string content = "example keyword" + DateTime.Now.ToString();
        batch.Add((id, content));

        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    await connection.OpenAsync();

        //    using (SqlCommand command = new SqlCommand(query, connection))
        //    {
        //        command.Parameters.AddWithValue("@BatchSize", batchSize);

        //        using (SqlDataReader reader = await command.ExecuteReaderAsync())
        //        {
        //            while (await reader.ReadAsync())
        //            {
        //                int id = reader.GetInt32(0);
        //                string content = reader.GetString(1);
        //                batch.Add((id, content));
        //            }
        //        }
        //    }
        //}

        return batch;
    }

    private static async Task MarkRecordsAsProcessedAsync(string connectionString, string tableName, List<(int, string)> batch)
    {
        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    await connection.OpenAsync();

        //    foreach (var (id, _) in batch)
        //    {
        //        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        //        using (SqlCommand command = new SqlCommand(updateQuery, connection))
        //        {
        //            command.Parameters.AddWithValue("@ID", id);
        //            await command.ExecuteNonQueryAsync();
        //        }
        //    }
        //}
    }
}

public class DatabaseOptions
{
    public string ConnectionString { get; set; }
    public string TableName { get; set; }
    public int BatchSize { get; set; }
    public int PollingInterval { get; set; }
}

///// <summary>
///// Orleans�N���C�A���g���z�X�e�b�h�T�[�r�X�Ƃ��ĊǗ����A�A�v���P�[�V�����̃��C�t�T�C�N���ɑg�ݍ��ނ��ƂŁA�N���ƏI�����Ǘ�
///// </summary>
//public class OrleansClientHostedService : IHostedService
//{
//    private readonly IClusterClient _client;

//    public OrleansClientHostedService(IClusterClient client)
//    {
//        _client = client;
//    }

//    public async Task StartAsync(CancellationToken cancellationToken)
//    {
//        await _client.Connect(async ex =>
//        {
//            Console.WriteLine($"�ڑ����ɃG���[���������܂���: {ex.Message}");
//            await Task.Delay(TimeSpan.FromSeconds(2), cancellationToken);
//        });
//    }

//    public async Task StopAsync(CancellationToken cancellationToken)
//    {
//        return _client.Close();
//    }
//}

//using AccountTransfer.Interfaces;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Hosting;

//using IHost host = Host.CreateDefaultBuilder(args)
//    .UseOrleansClient(client =>
//    {
//        client.UseLocalhostClustering()
//            .UseTransactions();
//    })
//    .UseConsoleLifetime()
//    .Build();

//await host.StartAsync();

//var client = host.Services.GetRequiredService<IClusterClient>();
//var transactionClient = host.Services.GetRequiredService<ITransactionClient>();
//var lifetime = host.Services.GetRequiredService<IHostApplicationLifetime>();

//var accountNames = new[] { "Xaawo", "Pasqualino", "Derick", "Ida", "Stacy", "Xiao" };
//var random = Random.Shared;

//while (!lifetime.ApplicationStopping.IsCancellationRequested)
//{
//    // Choose some random accounts to exchange money
//    var fromIndex = random.Next(accountNames.Length);
//    var toIndex = random.Next(accountNames.Length);
//    while (toIndex == fromIndex)
//    {
//        // Avoid transferring to/from the same account, since it would be meaningless
//        toIndex = (toIndex + 1) % accountNames.Length;
//    }

//    var fromKey = accountNames[fromIndex];
//    var toKey = accountNames[toIndex];
//    var fromAccount = client.GetGrain<IAccountGrain>(fromKey);
//    var toAccount = client.GetGrain<IAccountGrain>(toKey);

//    // Perform the transfer and query the results
//    try
//    {
//        var transferAmount = random.Next(200);

//        await transactionClient.RunTransaction(
//            TransactionOption.Create,
//            async () =>
//            {
//                await fromAccount.Withdraw(transferAmount);
//                await toAccount.Deposit(transferAmount);
//            });

//        var fromBalance = await fromAccount.GetBalance();
//        var toBalance = await toAccount.GetBalance();

//        Console.WriteLine(
//            $"We transferred {transferAmount} credits from {fromKey} to " +
//            $"{toKey}.\n{fromKey} balance: {fromBalance}\n{toKey} balance: {toBalance}\n");
//    }
//    catch (Exception exception)
//    {
//        Console.WriteLine(
//            $"Error transferring credits from " +
//            $"{fromKey} to {toKey}: {exception.Message}");

//        if (exception.InnerException is { } inner)
//        {
//            Console.WriteLine($"\tInnerException: {inner.Message}\n");
//        }

//        Console.WriteLine();
//    }

//    // Sleep and run again
//    await Task.Delay(TimeSpan.FromMilliseconds(200));
//}