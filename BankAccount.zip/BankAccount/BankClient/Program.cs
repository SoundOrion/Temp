using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using GrainInterfaces;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Orleans.Serialization.Buffers;

public class Program
{
    private static BlockingCollection<List<(int, string)>> queue = new BlockingCollection<List<(int, string)>>();

    static async Task Main(string[] args)
    {
        using IHost host = Host.CreateDefaultBuilder(args)
    .UseOrleansClient(client =>
    {
        client.UseLocalhostClustering()
                .Configure<ClusterOptions>(options =>
                 {
                     options.ClusterId = "dev";
                     options.ServiceId = "OrleansSampleApp";
                 });
    })
    .ConfigureLogging(logging => logging.AddConsole())
    .UseConsoleLifetime()
    .Build();


        await host.StartAsync();

        var client = host.Services.GetRequiredService<IClusterClient>();



        var producerTask = Task.Run(() => ProduceAsync(client));
        var consumerTask = Task.Run(() => ConsumeAsync(client));
        await Task.WhenAll(producerTask, consumerTask);
        //await ProduceAndConsumeAsync(client);
    }

    private static async Task<IClusterClient> StartClientAsync(string[] args)
    {
        using IHost host = Host.CreateDefaultBuilder(args)
    .UseOrleansClient(client =>
    {
        client.UseLocalhostClustering();
    })
    .ConfigureLogging(logging => logging.AddConsole())
    .UseConsoleLifetime()
    .Build();


        await host.StartAsync();

        var client = host.Services.GetRequiredService<IClusterClient>();

        return client;
    }

    private static async Task ProduceAsync(IClusterClient client)
    {
        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int batchSize = 1; // �o�b�`�T�C�Y���w��
        int pollingInterval = 2000; // 2�b���ƂɃ|�[�����O

        while (true)
        {
            try
            {
                var batch = await CheckDatabaseAsync(connectionString, tableName, batchSize);
                if (batch.Count > 0)
                {
                    queue.Add(batch);
                    await MarkRecordsAsProcessedAsync(connectionString, tableName, batch);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"�f�[�^�x�[�X�̃`�F�b�N���ɃG���[���������܂���: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task ConsumeAsync(IClusterClient client)
    {
        var processingGrain = client.GetGrain<IProcessingGrain>(0);

        foreach (var batch in queue.GetConsumingEnumerable())
        {
            await processingGrain.ProcessBatchAsync(batch);
        }
    }

    private static async Task<List<(int, string)>> CheckDatabaseAsync(string connectionString, string tableName, int batchSize)
    {
        string query = $"SELECT TOP (@BatchSize) * FROM {tableName} WHERE Processed = 0";
        var batch = new List<(int, string)>();
        int id = int.Parse(DateTime.Today.ToOADate().ToString());
        string content = "example keyword" + DateTime.Now.ToString();
        batch.Add((id, content));

        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    await connection.OpenAsync();

        //    using (SqlCommand command = new SqlCommand(query, connection))
        //    {
        //        command.Parameters.AddWithValue("@BatchSize", batchSize);

        //        using (SqlDataReader reader = await command.ExecuteReaderAsync())
        //        {
        //            while (await reader.ReadAsync())
        //            {
        //                int id = reader.GetInt32(0);
        //                string content = reader.GetString(1);
        //                batch.Add((id, content));
        //            }
        //        }
        //    }
        //}

        return batch;
    }

    private static async Task MarkRecordsAsProcessedAsync(string connectionString, string tableName, List<(int, string)> batch)
    {
        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    await connection.OpenAsync();

        //    foreach (var (id, _) in batch)
        //    {
        //        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        //        using (SqlCommand command = new SqlCommand(updateQuery, connection))
        //        {
        //            command.Parameters.AddWithValue("@ID", id);
        //            await command.ExecuteNonQueryAsync();
        //        }
        //    }
        //}
    }

    private static async Task ProduceAndConsumeAsync(IClusterClient client)
    {
        var processingGrain = client.GetGrain<IProcessingGrain>(0);

        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int batchSize = 1; // �o�b�`�T�C�Y���w��
        int pollingInterval = 2000; // 2�b���ƂɃ|�[�����O

        while (true)
        {
            try
            {
                var batch = await CheckDatabaseAsync(connectionString, tableName, batchSize);
                if (batch.Count > 0)
                {
                    await processingGrain.ProcessBatchAsync(batch);
                    await MarkRecordsAsProcessedAsync(connectionString, tableName, batch);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"�f�[�^�x�[�X�̃`�F�b�N���ɃG���[���������܂���: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }
}

//using AccountTransfer.Interfaces;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Hosting;

//using IHost host = Host.CreateDefaultBuilder(args)
//    .UseOrleansClient(client =>
//    {
//        client.UseLocalhostClustering()
//            .UseTransactions();
//    })
//    .UseConsoleLifetime()
//    .Build();

//await host.StartAsync();

//var client = host.Services.GetRequiredService<IClusterClient>();
//var transactionClient = host.Services.GetRequiredService<ITransactionClient>();
//var lifetime = host.Services.GetRequiredService<IHostApplicationLifetime>();

//var accountNames = new[] { "Xaawo", "Pasqualino", "Derick", "Ida", "Stacy", "Xiao" };
//var random = Random.Shared;

//while (!lifetime.ApplicationStopping.IsCancellationRequested)
//{
//    // Choose some random accounts to exchange money
//    var fromIndex = random.Next(accountNames.Length);
//    var toIndex = random.Next(accountNames.Length);
//    while (toIndex == fromIndex)
//    {
//        // Avoid transferring to/from the same account, since it would be meaningless
//        toIndex = (toIndex + 1) % accountNames.Length;
//    }

//    var fromKey = accountNames[fromIndex];
//    var toKey = accountNames[toIndex];
//    var fromAccount = client.GetGrain<IAccountGrain>(fromKey);
//    var toAccount = client.GetGrain<IAccountGrain>(toKey);

//    // Perform the transfer and query the results
//    try
//    {
//        var transferAmount = random.Next(200);

//        await transactionClient.RunTransaction(
//            TransactionOption.Create,
//            async () =>
//            {
//                await fromAccount.Withdraw(transferAmount);
//                await toAccount.Deposit(transferAmount);
//            });

//        var fromBalance = await fromAccount.GetBalance();
//        var toBalance = await toAccount.GetBalance();

//        Console.WriteLine(
//            $"We transferred {transferAmount} credits from {fromKey} to " +
//            $"{toKey}.\n{fromKey} balance: {fromBalance}\n{toKey} balance: {toBalance}\n");
//    }
//    catch (Exception exception)
//    {
//        Console.WriteLine(
//            $"Error transferring credits from " +
//            $"{fromKey} to {toKey}: {exception.Message}");

//        if (exception.InnerException is { } inner)
//        {
//            Console.WriteLine($"\tInnerException: {inner.Message}\n");
//        }

//        Console.WriteLine();
//    }

//    // Sleep and run again
//    await Task.Delay(TimeSpan.FromMilliseconds(200));
//}