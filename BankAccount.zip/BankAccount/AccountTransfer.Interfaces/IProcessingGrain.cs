﻿using Orleans;

namespace GrainInterfaces;

/// <summary>
/// グレイン インターフェイスを定義する（コンシューマー）
/// </summary>
public interface IProcessingGrain : IGrainWithGuidKey
{
    ValueTask ProcessBatchAsync(List<(int, string)> batch);
}
