﻿using Orleans;

namespace GrainInterfaces;

/// <summary>
/// グレイン インターフェイスを定義する（コンシューマー）
/// </summary>
public interface IProcessingGrain : IGrainWithIntegerKey
{
    ValueTask ProcessBatchAsync(List<(int, string)> batch);
}
