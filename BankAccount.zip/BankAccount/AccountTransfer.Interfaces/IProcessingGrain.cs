﻿using Orleans;

namespace GrainInterfaces;

/// <summary>
/// グレイン インターフェイスを定義する（コンシューマー）
/// </summary>
public interface IProcessingGrain : IGrainWithStringKey
{
    Task ProcessBatchAsync(List<(int, string)> batch);
}
