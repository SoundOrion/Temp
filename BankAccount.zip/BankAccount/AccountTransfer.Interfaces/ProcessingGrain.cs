﻿using Orleans;
using GrainInterfaces;
using Microsoft.Extensions.Logging;

namespace Grains;

/// <summary>
/// グレイン クラスを定義する
/// </summary>
public class ProcessingGrain : Grain, IProcessingGrain
{
    private readonly ILogger<ProcessingGrain> _logger;

    public ProcessingGrain(ILogger<ProcessingGrain> logger) => _logger = logger;

    public ValueTask ProcessBatchAsync(List<(int, string)> batch)
    {
        foreach (var (id, content) in batch)
        {
            if (content.Contains("example keyword"))
            {
                Console.WriteLine($"ID={id}: キーワードが含まれています。処理を行います。");

                //_logger.LogInformation($"ID={id}: キーワードが含まれています。処理を行います。");

                // 処理の実装
            }
            else
            {
                Console.WriteLine($"ID={id}: キーワードは含まれていません。");

                //_logger.LogInformation($"ID={id}: キーワードは含まれていません。");
            }
        }
        return ValueTask.CompletedTask;
    }
}
