﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize("ApiAccess")] // Web APIアクセスを許可する
public class ImagesController : ControllerBase
{
    private readonly string _imagesDirectoryPath; // 画像が保存されているディレクトリのパス

    public ImagesController(IWebHostEnvironment environment)
    {
        _imagesDirectoryPath = Path.Combine(environment.WebRootPath, "images");
    }

    [HttpGet("{imageName}")]
    public IActionResult GetImage(string imageName)
    {
        var imagePath = Path.Combine(_imagesDirectoryPath, imageName);

        // ファイルが存在しない場合は404 Not Foundを返す
        if (!System.IO.File.Exists(imagePath))
        {
            return NotFound();
        }

        // 画像ファイルを読み込んでバイト配列に変換
        byte[] imageBytes = System.IO.File.ReadAllBytes(imagePath);

        // 画像のContent-Typeを決定
        string contentType = GetContentType(imagePath);

        // バイト配列とContent-Typeを指定してファイルを返す
        return File(imageBytes, contentType);
    }

    // 画像のContent-Typeを取得するメソッド
    private string GetContentType(string imagePath)
    {
        switch (Path.GetExtension(imagePath).ToLowerInvariant())
        {
            case ".jpg":
            case ".jpeg":
                return "image/jpeg";
            case ".png":
                return "image/png";
            case ".gif":
                return "image/gif";
            default:
                return "application/octet-stream";
        }
    }
}
