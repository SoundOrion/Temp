﻿using Microsoft.JSInterop;
using System.Threading.Tasks;

namespace BlazorAppPDF;

public class PrintService_
{
    private readonly IJSRuntime _jsRuntime;

    public PrintService_(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task PrintRawHtmlToPdf(string rawHtml)
    {
        await _jsRuntime.InvokeVoidAsync("printJS", rawHtml, "raw-html");
    }
}
