using Microsoft.AspNetCore.SignalR;
using Orleans.Configuration;
using SignalROrleansExample.Hubs;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSignalR();

builder.Services.AddSingleton<IGrainFactory>(sp =>
{
    var client = new ClientBuilder()
        .UseLocalhostClustering()
        .Configure<ClusterOptions>(options =>
        {
            options.ClusterId = "dev";
            options.ServiceId = "SignalROrleansExample";
        })
        .Build();
    client.Connect().Wait();
    return client;
});

builder.Services.AddSingleton<IHubContext<ChatHub>, HubContext<ChatHub>>();

var app = builder.Build();

app.UseEndpoints(endpoints =>
{
    endpoints.MapHub<ChatHub>("/chatHub");
});

var silo = new SiloHostBuilder()
    .UseLocalhostClustering()
    .Configure<ClusterOptions>(options =>
    {
        options.ClusterId = "dev";
        options.ServiceId = "SignalROrleansExample";
    })
    .ConfigureApplicationParts(parts => parts.AddApplicationPart(typeof(ChatGrain).Assembly).WithReferences())
    .ConfigureLogging(logging => logging.AddConsole())
    .Build();

silo.StartAsync().Wait();

lifetime.ApplicationStopping.Register(() =>
{
    silo.StopAsync().Wait();
});

app.MapGet("/", () => "Hello World!");

app.Run();
