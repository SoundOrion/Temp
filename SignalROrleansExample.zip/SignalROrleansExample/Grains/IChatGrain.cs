﻿using Orleans;
using System.Threading.Tasks;

namespace SignalROrleansExample.Grains
{
    public interface IChatGrain : IGrainWithStringKey
    {
        Task SendMessage(string user, string message);
    }
}
