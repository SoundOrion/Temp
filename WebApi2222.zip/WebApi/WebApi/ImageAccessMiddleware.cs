﻿namespace WebApi;


public class ImageAccessMiddleware
{
    private readonly RequestDelegate _next;

    public ImageAccessMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        // 画像へのリクエストかどうかをチェック
        if (IsImageRequest(context.Request.Path))
        {
            // リクエストが直接アクセスされた場合、403 Forbiddenを返す
            context.Response.StatusCode = StatusCodes.Status403Forbidden;
            await context.Response.WriteAsync("Direct access to images is forbidden.");
            return;
        }

        // 画像への直接アクセスでない場合は、次のミドルウェアに処理を移す
        await _next(context);
    }

    private bool IsImageRequest(PathString path)
    {
        if (path.ToString().StartsWith("/api"))
        {
            return false;
        }

        string extension = Path.GetExtension(path);
        if (!string.IsNullOrEmpty(extension))
        {
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
            return Array.IndexOf(imageExtensions, extension.ToLower()) != -1;
        }
        return false;
    }
}


//public class ImageAccessMiddleware
//{
//    private readonly RequestDelegate _next;

//    public ImageAccessMiddleware(RequestDelegate next)
//    {
//        _next = next;
//    }

//    public async Task Invoke(HttpContext context)
//    {
//        // リクエストがBlazorページからのものか、直接URLからのものかを判断する
//        if (IsDirectUrlRequest(context.Request.Headers["Referer"]))
//        {
//            // 直接URLからのリクエストの場合は制限を適用する
//            context.Response.StatusCode = StatusCodes.Status403Forbidden;
//            await context.Response.WriteAsync("Direct access to images is forbidden.");
//            return;
//        }

//        // Blazorページからのリクエストの場合は制限を適用しない
//        await _next(context);
//    }

//    private bool IsDirectUrlRequest(string referer)
//    {
//        // Refererヘッダーがnullである場合、直接URLからのリクエストとみなす
//        return string.IsNullOrEmpty(referer);
//    }
//}
