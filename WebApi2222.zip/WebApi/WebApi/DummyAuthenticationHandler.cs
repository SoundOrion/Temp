﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace WebApi;

//public class DummyAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
//{
//    public DummyAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
//        ILoggerFactory logger,
//        UrlEncoder encoder,
//        ISystemClock clock)
//        : base(options, logger, encoder, clock)
//    {
//    }

//    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
//    {
//        // ここで認証を行う
//        // 今回は常に成功するダミーの認証処理を行う
//        var identity = new ClaimsIdentity("DummyAuthentication");
//        var principal = new ClaimsPrincipal(identity);
//        var ticket = new AuthenticationTicket(principal, "DummyAuthentication");

//        return AuthenticateResult.Success(ticket);
//    }
//}


public class DummyAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    //private readonly ILogger<DummyAuthenticationHandler> _logger;

    //public DummyAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
    //    ILoggerFactory logger,
    //    UrlEncoder encoder,
    //    ISystemClock clock,
    //    ILogger<DummyAuthenticationHandler> logger)
    //    : base(options, logger, encoder, clock)
    //{
    //    _logger = logger;
    //}

    public DummyAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        ISystemClock clock)
        : base(options, logger, encoder, clock)
    {
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        // ダミーのトークンを取得
        string token = Request.Headers["Authorization"];

        // トークンの検証
        if (!string.IsNullOrEmpty(token) && token.StartsWith("Bearer "))
        {
            token = token.Substring("Bearer ".Length).Trim();
            if (ValidateDummyToken(token))
            {
                // トークンが有効な場合は、ユーザー情報を設定して認証成功として返す
                var claims = new[] { new Claim(ClaimTypes.Name, "DummyUser") };
                var identity = new ClaimsIdentity(claims, Scheme.Name);
                var principal = new ClaimsPrincipal(identity);
                var ticket = new AuthenticationTicket(principal, Scheme.Name);
                return AuthenticateResult.Success(ticket);
            }
        }

        // 認証失敗の場合、403 Forbidden を返す
        Response.StatusCode = 403;
        await Response.WriteAsync("Forbidden");
        await Response.CompleteAsync();
        return AuthenticateResult.Fail("Invalid token");
    }

    public bool ValidateDummyToken(string token)
    {
        // トークンの形式が適切かどうかを検証するロジック
        // この例では単純にトークンの長さをチェックしていますが、実際のシステムでは署名の検証なども行う必要があります
        return !string.IsNullOrEmpty(token) && token.Length > 10;
    }
}

