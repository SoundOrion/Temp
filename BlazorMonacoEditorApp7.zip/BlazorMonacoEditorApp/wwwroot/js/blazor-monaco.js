﻿export function initializeMonacoEditor(editorId, initialValue, dotnetHelper) {

    //require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.28.1/min/vs' } });
    require.config({
        paths: {
            "vs": "/monaco/min/vs"
        }
    });

    require(['vs/editor/editor.main'], function () {

        const editorElement = document.getElementById(editorId);

        if (editorElement) {

            let monacoOptions = {
                value: '# Markdown Example\n\nThis is a sample Markdown document.',
                language: 'markdown',
                theme: 'vs-dark',
                readOnly: false,
                fontSize: 14,
                lineHeight: 22,
                lineNumbers: 'off',
                wordWrap: 'on',
                minimap: {
                    enabled: true,
                    renderCharacters: false
                },
                autoClosingBrackets: 'languageDefined',
                autoClosingQuotes: 'languageDefined',
                formatOnPaste: true,
                formatOnType: true,
                cursorBlinking: 'blink',
                cursorStyle: 'line',
                smoothScrolling: true,
                scrollBeyondLastLine: false,
                suggestOnTriggerCharacters: true,
                acceptSuggestionOnEnter: 'on',
                quickSuggestions: {
                    other: true,
                    comments: true,
                    strings: true
                },
                parameterHints: {
                    enabled: true
                },
                lightbulb: {
                    enabled: true
                },
                codeLens: true,
                folding: true
            }
            window.monacoEditor = monaco.editor.create(document.getElementById(editorId), monacoOptions);

            // リアルタイムのコンテンツ変更リスナーを設定します
            window.monacoEditor.onDidChangeModelContent(function () {
                const content = window.monacoEditor.getValue();
                dotnetHelper.invokeMethodAsync('UpdatePreview', content);
            });

            // カスタムの補完プロバイダーを登録
            monaco.languages.registerCompletionItemProvider('markdown', {
                provideCompletionItems: function (model, position) {
                    const suggestions = [
                        {
                            label: 'bold',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '**${1:bold text}**',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert bold text'
                        },
                        {
                            label: 'italic',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '*${1:italic text}*',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert italic text'
                        },
                        {
                            label: 'link',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '[${1:text}](http://${2:url})',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert link'
                        },
                        {
                            label: 'image',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '![${1:alt text}](http://${2:url})',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert image'
                        },
                        {
                            label: 'Code Block',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '```\n$0\n```',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a Markdown code block'
                        },
                        {
                            label: 'Inline Code',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '`$0`',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert inline code'
                        },
                        {
                            label: 'Strikethrough',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '~~${1:text}~~',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a Markdown strikethrough'
                        },
                        {
                            label: 'table',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '| Header 1 | Header 2 |\n|----------|----------|\n| Cell 1   | Cell 2   |\n| Cell 3   | Cell 4   |',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a Markdown table'
                        },
                        {
                            label: 'Details',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '<details>\n  <summary>$0</summary>\n  $1\n</details>',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a collapsible details section'
                        },
                        // 順序なしリスト
                        {
                            label: 'Bullet List',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '* $0\n* $1',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a bullet list'
                        },
                        // 番号付きリスト
                        {
                            label: 'Ordered List',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '1. $0\n2. $1',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert an ordered list'
                        },
                        // 補足説明
                        {
                            label: 'Note',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '> **Note:** $0',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a note'
                        },
                        // チェックボックス
                        {
                            label: 'Checkbox',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '- [ ] $0',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a checkbox'
                        },
                        // 引用
                        {
                            label: 'Blockquotes',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '> $0',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a blockquote'
                        },
                        // 水平線
                        {
                            label: 'Horizontal Rule',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '---',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a horizontal rule'
                        },
                        // 数式の挿入（KaTeXやMathJaxのサポートが必要）
                        {
                            label: 'Math Formula',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '$${1:formula}$$',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a LaTeX math formula'
                        },
                        // リンクカード（外部プラグインやカスタム処理が必要）
                        {
                            label: 'Link Card',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '[${1:text}](${2:url})',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a link card'
                        },
                        // PlantUML
                        {
                            label: 'PlantUML Diagram',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '@startuml\n${1}\n@enduml',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a PlantUML diagram'
                        },
                        // Mermaid
                        {
                            label: 'Mermaid Diagram',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '```mermaid\n${1}\n```',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a Mermaid diagram'
                        },
                        {
                            label: 'HTML Block',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '<div>${1:content}</div>',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert an HTML block'
                        },
                        {
                            label: 'Footnote',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '[^${1:footnote}]: ${2:Footnote text}',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a Markdown footnote'
                        },
                        //{
                        //    label: 'Math Expression',
                        //    kind: monaco.languages.CompletionItemKind.Snippet,
                        //    insertText: '$${1:math expression}$$',
                        //    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        //    documentation: 'Insert a mathematical expression using LaTeX'
                        //},
                        //{
                        //    label: 'Embed URL',
                        //    kind: monaco.languages.CompletionItemKind.Snippet,
                        //    insertText: '[${1:text}](${2:url})',
                        //    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        //    documentation: 'Embed a URL in Markdown'
                        //},
                        //{
                        //    label: 'Custom HTML Element',
                        //    kind: monaco.languages.CompletionItemKind.Snippet,
                        //    insertText: '<${1:custom-tag}>${2:content}</${1:custom-tag}>',
                        //    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        //    documentation: 'Insert a custom HTML element'
                        //},
                        //{
                        //    label: 'Link Reference',
                        //    kind: monaco.languages.CompletionItemKind.Snippet,
                        //    insertText: '[${1:link text}][${2:reference}]\n\n[${2:reference}]: ${3:url}',
                        //    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        //    documentation: 'Insert a Markdown link reference'
                        //}
                        // 見出しレベル1
                        {
                            label: 'Heading 1',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '# ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 1 heading'
                        },
                        // 見出しレベル2
                        {
                            label: 'Heading 2',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '## ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 2 heading'
                        },
                        // 見出しレベル3
                        {
                            label: 'Heading 3',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '### ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 3 heading'
                        },
                        // 見出しレベル4
                        {
                            label: 'Heading 4',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '#### ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 4 heading'
                        },
                        // 見出しレベル5
                        {
                            label: 'Heading 5',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '##### ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 5 heading'
                        },
                        // 見出しレベル6
                        {
                            label: 'Heading 6',
                            kind: monaco.languages.CompletionItemKind.Snippet,
                            insertText: '###### ${1:Heading}\n',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            documentation: 'Insert a level 6 heading'
                        }
                    ];
                    return { suggestions: suggestions };
                }
            });
        }
    });
};
export function initializeResizable() {
    const editor = document.getElementById('editor');
    const preview = document.getElementById('preview');
    const container = document.querySelector('.resizable-container');
    const resizer = document.querySelector('.resizer');
    const toggleEditorButton = document.getElementById('toggleEditorButton');

    if (editor && preview && container && resizer) {
        let isResizing = false;
        let userSelectBackup = '';

        function disableTextSelection() {
            userSelectBackup = document.body.style.userSelect;
            document.body.style.userSelect = 'none';
        }

        function enableTextSelection() {
            document.body.style.userSelect = userSelectBackup;
        }

        resizer.addEventListener('mousedown', function (e) {
            isResizing = true;
            disableTextSelection(); // テキスト選択を無効にする
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        function onMouseMove(e) {
            if (isResizing) {
                requestAnimationFrame(() => {
                    const containerRect = container.getBoundingClientRect();

                    // 新しい幅の計算
                    const minWidth = 50;
                    let newEditorWidth = e.clientX - containerRect.left;
                    let newPreviewWidth = containerRect.right - e.clientX;

                    // 最小幅と最大幅の制約を設定
                    newEditorWidth = Math.max(minWidth, Math.min(newEditorWidth, containerRect.width - minWidth));
                    newPreviewWidth = Math.max(minWidth, Math.min(newPreviewWidth, containerRect.width - minWidth));

                    // 幅の変更が有効な場合にのみ適用
                    if (newEditorWidth >= minWidth && newPreviewWidth >= minWidth) {
                        editor.style.flexBasis = newEditorWidth + 'px';
                        preview.style.flexBasis = newPreviewWidth + 'px';
                        resizer.style.left = (newEditorWidth - 5) + 'px'; // resizerの位置を更新
                    }
                });
            }
        }

        function onMouseUp() {
            isResizing = false;
            enableTextSelection(); // テキスト選択を元に戻す
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }

        // コンテンツの変更時にリサイズバーの位置を更新する
        function updateResizerPosition() {
            const editorWidth = editor.getBoundingClientRect().width;
            resizer.style.left = (editorWidth - 5) + 'px'; // エディタの幅に基づいてリサイズバーの位置を設定
        }

        //function stopResize() {
        //    isResizing = false;
        //    enableTextSelection();
        //    document.removeEventListener('mousemove', onMouseMove);
        //    document.removeEventListener('mouseup', stopResize);
        //}

        //function disableTextSelection() {
        //    document.body.style.userSelect = 'none';
        //}

        //function enableTextSelection() {
        //    document.body.style.userSelect = '';
        //}

        //function toggleEditor() {
        //    if (editor.style.display === 'none') {
        //        editor.style.display = 'block';
        //        preview.style.flexBasis = '50%'; // エディタが表示されるので、幅を50%に戻す
        //    } else {
        //        editor.style.display = 'none';
        //        preview.style.flexBasis = '100%'; // エディタが非表示なので、プレビューの幅を100%にする
        //    }
        //    updateResizerPosition(); // リサイズバーの位置を更新
        //}

        function toggleEditor() {
            if (editor.style.display === 'none') {
                editor.style.display = 'block';
                resizer.style.display = 'block';
                preview.style.flexBasis = '50%'; // エディタが表示されるので、幅を50%に戻す
            } else {
                editor.style.display = 'none';
                resizer.style.display = 'none';
                preview.style.flexBasis = '100%'; // エディタが非表示なので、プレビューの幅を100%にする
            }
            updateResizerPosition(); // リサイズバーの位置を更新
        }

        window.toggleEditor = toggleEditor; // toggleEditor関数をグローバルに公開

        // 初期状態でリサイズバーの位置を更新
        updateResizerPosition();

        // ウィンドウリサイズ時にもリサイズバーの位置を更新
        window.addEventListener('resize', updateResizerPosition);

        // エディタの内容が変更されたときにもリサイズバーの位置を更新
        editor.addEventListener('input', updateResizerPosition);

        // 文字削除時にもリサイズバーの位置を更新
        // keydown と keyup イベントは、文字削除だけでなく他のキー操作もキャッチするため、input イベントが推奨
        editor.addEventListener('keydown', updateResizerPosition); // オプションで追加

    }
}


//window.getMonacoEditorValue = (editorId) => {
//    return window.monacoEditor.getValue();
//};

//window.onEditorContentChanged = (editorId, initialValue, dotnetHelper) => {
//    if (window.monacoEditor) {
//        window.monacoEditor.onDidChangeModelContent(function () {
//            const content = window.monacoEditor.getValue();
//            dotnetHelper.invokeMethodAsync('UpdatePreview', content);
//        });
//    }
//};

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        resizer.addEventListener('mousedown', function (e) {
//            document.addEventListener('mousemove', resize);
//            document.addEventListener('mouseup', stopResize);
//        });

//        function resize(e) {
//            const containerRect = container.getBoundingClientRect();
//            const newEditorWidth = e.clientX - containerRect.left;
//            const newPreviewWidth = containerRect.right - e.clientX;

//            if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                editor.style.flexBasis = newEditorWidth + 'px';
//                preview.style.flexBasis = newPreviewWidth + 'px';
//                resizer.style.right = newPreviewWidth + 'px';
//            }
//        }

//        function stopResize() {
//            document.removeEventListener('mousemove', resize);
//            document.removeEventListener('mouseup', stopResize);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();
//                    const newEditorWidth = e.clientX - containerRect.left;
//                    const newPreviewWidth = containerRect.right - e.clientX;

//                    if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.right = newPreviewWidth + 'px';
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;
//        let userSelectBackup = '';

//        // テキスト選択を無効にする関数
//        function disableTextSelection() {
//            userSelectBackup = document.body.style.userSelect;
//            document.body.style.userSelect = 'none';
//        }

//        // テキスト選択を有効に戻す関数
//        function enableTextSelection() {
//            document.body.style.userSelect = userSelectBackup;
//        }

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            disableTextSelection(); // テキスト選択を無効にする
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();
//                    const newEditorWidth = e.clientX - containerRect.left;
//                    const newPreviewWidth = containerRect.right - e.clientX;

//                    if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.right = newPreviewWidth + 'px';
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            enableTextSelection(); // テキスト選択を元に戻す
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;
//        let userSelectBackup = '';

//        function disableTextSelection() {
//            userSelectBackup = document.body.style.userSelect;
//            document.body.style.userSelect = 'none';
//        }

//        function enableTextSelection() {
//            document.body.style.userSelect = userSelectBackup;
//        }

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            disableTextSelection(); // テキスト選択を無効にする
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();

//                    // 現在のエディタとプレビューの幅
//                    const editorWidth = editor.getBoundingClientRect().width;
//                    const previewWidth = preview.getBoundingClientRect().width;

//                    // 最小幅の設定
//                    const minWidth = 50;

//                    // 新しい幅の計算
//                    let newEditorWidth = e.clientX - containerRect.left;
//                    let newPreviewWidth = containerRect.right - e.clientX;

//                    // 幅が最小幅以上であり、かつコンテナの幅を超えないように制約
//                    if (newEditorWidth >= minWidth && newPreviewWidth >= minWidth) {
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.left = newEditorWidth + 'px'; // resizerの位置を更新
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            enableTextSelection(); // テキスト選択を元に戻す
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}



//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;
//        let userSelectBackup = '';

//        function disableTextSelection() {
//            userSelectBackup = document.body.style.userSelect;
//            document.body.style.userSelect = 'none';
//        }

//        function enableTextSelection() {
//            document.body.style.userSelect = userSelectBackup;
//        }

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            disableTextSelection(); // テキスト選択を無効にする
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();

//                    // コンテナの幅を取得
//                    const containerWidth = containerRect.width;

//                    // 新しい幅の計算
//                    const minWidth = 50;
//                    let newEditorWidth = e.clientX - containerRect.left;
//                    let newPreviewWidth = containerRect.right - e.clientX;

//                    // エディタとプレビューの幅が最小幅以上であり、かつコンテナの幅を超えないように制約
//                    if (newEditorWidth >= minWidth && newPreviewWidth >= minWidth && newEditorWidth + newPreviewWidth <= containerWidth) {
//                        resizer.style.left = newEditorWidth + 'px'; // resizerの位置を更新
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';                 
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            enableTextSelection(); // テキスト選択を元に戻す
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}


