﻿namespace BlazorAppPDF.Printing;

public enum PrintType
{
    Pdf,
    Html,
    Image,
    Json,
    RawHtml
}
