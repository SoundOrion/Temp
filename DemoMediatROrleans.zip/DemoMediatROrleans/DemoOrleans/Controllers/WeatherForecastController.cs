using Microsoft.AspNetCore.Mvc;
using DemoOrleans.Grains;
using DemoShared;

namespace DemoOrleans.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private readonly IGrainFactory _grainFactory;

    public WeatherForecastController(IGrainFactory grainFactory) => _grainFactory = grainFactory;

    [HttpGet(Name = "GetWeatherForecast")]
    public async Task<IEnumerable<WeatherForecast>> GetAsync()
    {
        var grain = _grainFactory.GetGrain<IWeatherForecastGrain>(Guid.NewGuid());
        return await grain.GetForecast();
    }
}
