using Microsoft.AspNetCore.Mvc;
using MediatR;
using DemoShared;

namespace DemoMediatROrleans.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private readonly IMediator _mediator;

    public WeatherForecastController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpGet(Name = "GetWeatherForecast")]
    public async Task<IEnumerable<WeatherForecast>> Get()
    {
        return await _mediator.Send(new WeatherForecastQuery());
    }
}
