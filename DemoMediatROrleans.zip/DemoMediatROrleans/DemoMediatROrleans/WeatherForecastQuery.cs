﻿using MediatR;

namespace DemoMediatROrleans;

public class WeatherForecastQuery : IRequest<IEnumerable<WeatherForecast>>
{
}
