﻿using MediatR;
using DemoShared;

namespace DemoMediatROrleans;

public class WeatherForecastQuery : IRequest<IEnumerable<WeatherForecast>>
{
}
