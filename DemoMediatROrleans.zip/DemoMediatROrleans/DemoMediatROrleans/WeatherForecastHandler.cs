﻿using MediatR;
using DemoMediatROrleans.Grains;
using DemoShared;

namespace DemoMediatROrleans;

public class WeatherForecastHandler : IRequestHandler<WeatherForecastQuery, IEnumerable<WeatherForecast>>
{
    private readonly IGrainFactory _grainFactory;

    public WeatherForecastHandler(IGrainFactory grainFactory)
    {
        _grainFactory = grainFactory;
    }

    public async Task<IEnumerable<WeatherForecast>> Handle(WeatherForecastQuery request, CancellationToken cancellationToken)
    {
        var grain = _grainFactory.GetGrain<IWeatherForecastGrain>(Guid.NewGuid());
        return await grain.GetForecast();
    }
}
