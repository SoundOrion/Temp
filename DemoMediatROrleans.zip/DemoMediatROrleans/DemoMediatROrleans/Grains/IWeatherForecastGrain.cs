﻿namespace DemoMediatROrleans.Grains;

public interface IWeatherForecastGrain : IGrainWithGuidKey
{
    Task<IEnumerable<WeatherForecast>> GetForecast();
}
