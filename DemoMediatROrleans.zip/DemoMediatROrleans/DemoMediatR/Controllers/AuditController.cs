﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoMediatR.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuditController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<WeatherForecastController> _logger;

    public AuditController(
    IMediator mediator,
    ILogger<WeatherForecastController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    // POST api/<ValuesController>
    [HttpPost]
    public async Task Post([FromBody] string value)
    {
        await _mediator.Publish(new Audit { Message = value });
    }
}
