﻿using MediatR;
using DemoShared;

namespace DemoMediatR;

public class WeatherMessage:IRequest<WeatherForecast>
{
}
