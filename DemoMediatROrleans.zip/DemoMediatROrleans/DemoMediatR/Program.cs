using Autofac;
using Autofac.Extensions.DependencyInjection;
using DemoMediatR;
using DemoMediatR.Autofac;
using MediatR.Extensions.Autofac.DependencyInjection;
using MediatR.Extensions.Autofac.DependencyInjection.Builder;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddMediatR(c=>c.RegisterServicesFromAssemblyContaining<Program>());

// Call UseServiceProviderFactory on the Host sub property 
// �A�v���P�[�V�����̃z�X�g��Autofac���g�p����悤�ɃT�[�r�X�v���o�C�_�[�t�@�N�g����ݒ�
// ����ɂ��AAutofac���A�v���P�[�V�����̃T�[�r�X�̍쐬����ъǗ���S��
builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());

// ���̃R�[�h�u���b�N�ł́AAutofac�R���e�i���\�����Ă��܂��BAutofac�ɓo�^�����ׂ��T�[�r�X���w��
builder.Host.ConfigureContainer<ContainerBuilder>(builder =>
{
    //builder.RegisterType<CustomersRepository>()
    //    .As<ICustomersRepository>()
    //    .SingleInstance();

    //builder.RegisterModule<ProductModule>();

    //builder.RegisterModule<CarTransportModule>();

    //builder.Register(c => new Backend())
    //.As<IBackend>()
    //.SingleInstance();

    builder.RegisterType<Backend>()
    .As<IBackend>()
    .SingleInstance();

    var configuration = MediatRConfigurationBuilder.Create(typeof(Program).Assembly)
        .WithAllOpenGenericHandlerTypesRegistered()
        .WithRegistrationScope(RegistrationScope.Scoped) // currently only supported values are `Transient` and `Scoped`
        .Build();
    builder.RegisterMediatR(configuration);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

//public class CarTransportModule : Module
//{
//  public bool ObeySpeedLimit { get; set; }

//  protected override void Load(ContainerBuilder builder)
//  {
//    builder.Register(c => new Car(c.Resolve<IDriver>())).As<IVehicle>();

//    if (ObeySpeedLimit)
//      builder.Register(c => new SaneDriver()).As<IDriver>();
//    else
//      builder.Register(c => new CrazyDriver()).As<IDriver>();
//  }
//}