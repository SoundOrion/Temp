﻿using MediatR;

namespace DemoMediatR;

/// <summary>
/// Do not have any method definition
/// </summary>
public class Audit : INotification
{
    public string Message { get; set; }
}