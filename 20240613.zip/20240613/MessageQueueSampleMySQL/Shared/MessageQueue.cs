﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Shared;

//MessageQueue.cs: MySQLを使用してメッセージを保存し、スレッドの安全性を確保しています。EnqueueAsyncメソッドでメッセージをキューに追加し、DequeueAllAsyncメソッドで未処理のメッセージを取得して処理済みとしてマークします。
//Producer/Program.cs: メッセージを生成してデータベースに追加する役割を担います。
//Consumer/Program.cs: データベースからメッセージを取り出して処理する役割を担います。
//この方法により、MySQLを使用したプロデューサーとコンシューマーのメッセージキューが実現できます。
//実際のプロジェクトでは、接続文字列の管理やエラーハンドリング、スケーラビリティの考慮が必要です。

public static class MessageQueue
{
    private static readonly string connectionString = "Server=localhost;Database=MessageQueueDB;User ID=your_username;Password=your_password;";

    public static async Task EnqueueAsync(string message)
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();
            var command = new MySqlCommand("INSERT INTO Messages (Content) VALUES (@Content)", connection);
            command.Parameters.AddWithValue("@Content", message);
            await command.ExecuteNonQueryAsync();
        }
    }

    public static async Task<IEnumerable<string>> DequeueAllAsync()
    {
        var messages = new List<string>();

        using (var connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();
            var command = new MySqlCommand("SELECT Id, Content FROM Messages WHERE Processed = 0", connection);
            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    messages.Add(reader["Content"].ToString());
                }
            }

            // Mark messages as processed
            var updateCommand = new MySqlCommand("UPDATE Messages SET Processed = 1 WHERE Processed = 0", connection);
            await updateCommand.ExecuteNonQueryAsync();
        }

        return messages;
    }
}
