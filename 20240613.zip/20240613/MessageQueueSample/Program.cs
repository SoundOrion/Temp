﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

//BlockingCollection<T>: メモリ内キューとして使用しています。Addメソッドでメッセージを追加し、GetConsumingEnumerableメソッドでメッセージを消費します。
//Producer: メッセージを生成してキューに追加する役割を担います。
//Consumer: キューからメッセージを取り出して処理する役割を担います。
//CompleteAdding: プロデューサーがメッセージの追加を終了したことをキューに通知します。
//Thread.Sleep: メッセージの生成と処理のシミュレーションのために遅延を挿入しています。
//このサンプルは、簡単なメモリ内メッセージキューの実装ですが、実際のプロジェクトではスレッドの安全性やエラーハンドリングなども考慮する必要があります。
//また、よりスケーラブルなソリューションには、Azure Service Bus、RabbitMQ、Kafkaなどのメッセージブローカーを使用することを検討してください。

class Program
{
    static async Task Main(string[] args)
    {
        var messageQueue = new BlockingCollection<string>();

        // コンシューマーの開始
        var consumerTask = Task.Run(() => StartConsumer(messageQueue));

        // プロデューサーの開始
        var producerTask = Task.Run(() => StartProducer(messageQueue));

        await Task.WhenAll(producerTask, consumerTask);
    }

    static void StartProducer(BlockingCollection<string> queue)
    {
        for (int i = 0; i < 10; i++)
        {
            string message = $"Message {i}";
            queue.Add(message);
            Console.WriteLine($"Produced: {message}");
            Thread.Sleep(500); // メッセージ生成のシミュレーション
        }

        queue.CompleteAdding();
    }

    static void StartConsumer(BlockingCollection<string> queue)
    {
        foreach (var message in queue.GetConsumingEnumerable())
        {
            Console.WriteLine($"Consumed: {message}");
            Thread.Sleep(1000); // メッセージ処理のシミュレーション
        }
    }
}
