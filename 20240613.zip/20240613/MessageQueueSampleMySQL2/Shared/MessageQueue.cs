﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Shared;

public static class MessageQueue
{
    private static readonly string connectionString = "Server=localhost;Database=MessageQueueDB;User ID=your_username;Password=your_password;Pooling=true;Max Pool Size=100;";

    public static async Task EnqueueAsync(string message)
    {
        int retryCount = 3;
        int delay = 1000;

        for (int i = 0; i < retryCount; i++)
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    var command = new MySqlCommand("INSERT INTO Messages (Content) VALUES (@Content)", connection);
                    command.Parameters.AddWithValue("@Content", message);
                    await command.ExecuteNonQueryAsync();
                }
                return; // 成功したらループを抜ける
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                if (i == retryCount - 1) throw; // 最後のリトライでも失敗したら例外を再スロー
                await Task.Delay(delay);
            }
        }
    }

    public static async Task<IEnumerable<string>> DequeueBatchAsync(int batchSize)
    {
        var messages = new List<string>();

        using (var connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();
            var command = new MySqlCommand($"SELECT Id, Content FROM Messages WHERE Processed = 0 LIMIT {batchSize}", connection);
            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    messages.Add(reader["Content"].ToString());
                }
            }

            // Mark messages as processed
            var updateCommand = new MySqlCommand($"UPDATE Messages SET Processed = 1 WHERE Processed = 0 LIMIT {batchSize}", connection);
            await updateCommand.ExecuteNonQueryAsync();
        }

        return messages;
    }
}


//スケーラビリティの考慮には、システムの負荷が増加したときに適切に対応できるように設計と実装を行うことが含まれます。具体的には、以下のような点を考慮することが重要です。

//1. データベース接続プールの使用
//データベース接続の作成と破棄はコストが高いため、接続プールを使用して接続を再利用することが推奨されます。

//csharp
//コードをコピーする
//// Example of connection string with pooling
//private static readonly string connectionString = "Server=localhost;Database=MessageQueueDB;User ID=your_username;Password=your_password;Pooling=true;Max Pool Size=100;";
//2. メッセージのバッチ処理
//メッセージの処理や取得を一度に大量に行うことで、データベースとのやり取りを減らし、効率を向上させます。

//メッセージのバッチ取得
//csharp
//コードをコピーする
//public static async Task<IEnumerable<string>> DequeueBatchAsync(int batchSize)
//{
//    var messages = new List<string>();

//    using (var connection = new MySqlConnection(connectionString))
//    {
//        await connection.OpenAsync();
//        var command = new MySqlCommand($"SELECT Id, Content FROM Messages WHERE Processed = 0 LIMIT {batchSize}", connection);
//        using (var reader = await command.ExecuteReaderAsync())
//        {
//            while (await reader.ReadAsync())
//            {
//                messages.Add(reader["Content"].ToString());
//            }
//        }

//        // Mark messages as processed
//        var updateCommand = new MySqlCommand($"UPDATE Messages SET Processed = 1 WHERE Processed = 0 LIMIT {batchSize}", connection);
//        await updateCommand.ExecuteNonQueryAsync();
//    }

//    return messages;
//}
//3. 非同期処理
//非同期プログラミングを使用して、データベース操作やI/O操作の待ち時間を他の処理に利用します。これにより、スループットを向上させることができます。

//4. キューの分割
//メッセージキューを複数に分割することで、負荷を分散させます。特定のタイプのメッセージを特定のキューに送るようにして、キューごとに処理を分けることができます。

//5. リトライとエラーハンドリング
//メッセージの処理に失敗した場合、リトライ機能を実装し、エラーが発生した際に適切に対処することが重要です。

//リトライロジックの例
//csharp
//コードをコピーする
//public static async Task EnqueueAsync(string message)
//{
//    int retryCount = 3;
//    int delay = 1000;

//    for (int i = 0; i < retryCount; i++)
//    {
//        try
//        {
//            using (var connection = new MySqlConnection(connectionString))
//            {
//                await connection.OpenAsync();
//                var command = new MySqlCommand("INSERT INTO Messages (Content) VALUES (@Content)", connection);
//                command.Parameters.AddWithValue("@Content", message);
//                await command.ExecuteNonQueryAsync();
//            }
//            return; // 成功したらループを抜ける
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine($"Error: {ex.Message}");
//            if (i == retryCount - 1) throw; // 最後のリトライでも失敗したら例外を再スロー
//            await Task.Delay(delay);
//        }
//    }
//}
//6. 分散トランザクション
//複数の操作が一貫性を保つようにトランザクションを使用します。分散システムでは、トランザクションの一部が失敗した場合にロールバックすることが重要です。

//7. 負荷分散
//プロデューサーとコンシューマーが増加するにつれて、負荷分散を行うことで、システムの全体的なパフォーマンスを向上させます。複数のインスタンスを立てることで、処理能力を向上させます。