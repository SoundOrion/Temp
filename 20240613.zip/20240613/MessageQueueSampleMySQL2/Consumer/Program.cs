﻿using System;
using System.Threading.Tasks;
using Shared;

namespace Consumer;

class Program
{
    static async Task Main(string[] args)
    {
        const int batchSize = 10; // 一度に処理するメッセージの数

        while (true)
        {
            var messages = await MessageQueue.DequeueBatchAsync(batchSize);
            foreach (var message in messages)
            {
                Console.WriteLine($"Consumed: {message}");
                await Task.Delay(1000); // メッセージ処理のシミュレーション
            }

            await Task.Delay(1000); // 次のチェックまでの待機時間
        }
    }
}
