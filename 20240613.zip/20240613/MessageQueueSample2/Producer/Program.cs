﻿using System;
using System.Threading;
using Shared;

namespace Producer;

class Programd
{
    static void Main(string[] args)
    {
        for (int i = 0; i < 10; i++)
        {
            string message = $"Message {i}";
            MessageQueue.Enqueue(message);
            Console.WriteLine($"Produced: {message}");
            Thread.Sleep(500); // メッセージ生成のシミュレーション
        }
    }
}
