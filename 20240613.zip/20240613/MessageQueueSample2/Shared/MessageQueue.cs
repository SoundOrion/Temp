﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Shared;

//MessageQueue.cs: メッセージをファイルに保存し、ロックを使用してスレッドの安全性を確保しています。
//Producer/Program.cs: メッセージを生成してキューに追加する役割を担います。
//Consumer/Program.cs: キューからメッセージを取り出して処理する役割を担います。
//この実装は簡易的なものですが、プロデューサーとコンシューマーを別プロジェクトとして分離し、メッセージのやり取りを行う基本的な方法を示しています。
//実際のプロジェクトでは、ファイルベースではなくデータベースやメッセージブローカーを使用することが推奨されます。

public static class MessageQueue
{
    private static readonly string queueFilePath = @"\..\messageQueue.txt";
    private static readonly object lockObj = new object();

    public static void Enqueue(string message)
    {
        lock (lockObj)
        {
            File.AppendAllLines(queueFilePath, new[] { message });
        }
    }

    public static IEnumerable<string> DequeueAll()
    {
        lock (lockObj)
        {
            if (!File.Exists(queueFilePath))
            {
                yield break;
            }

            var messages = File.ReadAllLines(queueFilePath);
            File.Delete(queueFilePath);

            foreach (var message in messages)
            {
                yield return message;
            }
        }
    }
}
