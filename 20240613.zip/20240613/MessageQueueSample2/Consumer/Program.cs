﻿using System;
using System.Threading;
using Shared;

namespace Consumer;

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            foreach (var message in MessageQueue.DequeueAll())
            {
                Console.WriteLine($"Consumed: {message}");
                Thread.Sleep(1000); // メッセージ処理のシミュレーション
            }

            Thread.Sleep(1000); // 次のチェックまでの待機時間
        }
    }
}
