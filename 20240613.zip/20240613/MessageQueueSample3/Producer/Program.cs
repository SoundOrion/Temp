﻿using System;
using System.Threading.Tasks;
using Shared;

namespace Producer;

class Program
{
    static async Task Main(string[] args)
    {
        for (int i = 0; i < 10; i++)
        {
            string message = $"Message {i}";
            await MessageQueue.EnqueueAsync(message);
            Console.WriteLine($"Produced: {message}");
            await Task.Delay(500); // メッセージ生成のシミュレーション
        }
    }
}
