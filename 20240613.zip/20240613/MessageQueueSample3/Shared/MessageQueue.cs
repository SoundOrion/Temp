﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Shared;

//スケーラビリティを考慮したファイルベースのメッセージキューの実装は難しいですが、以下の点を考慮することである程度のスケーラビリティを確保できます。

//ファイルロックを使用して同時アクセスを制御
//バッチ処理を使用してメッセージの読み取り/書き込みを効率化
//メッセージの分割（シャーディング）
//非同期処理
//以下に、これらの要素を取り入れた実装例を示します。

//MessageQueue.cs: メッセージを個別のファイルに保存し、ファイルシステムを利用してメッセージをキューに追加およびバッチで取得します。EnqueueAsyncメソッドは新しいファイルを作成し、DequeueBatchAsyncメソッドは指定されたバッチサイズに従ってファイルを読み取り削除します。ファイル操作時の競合を防ぐためにlockを使用しています。
//Producer/Program.cs: メッセージを生成してファイルに追加する役割を担います。
//Consumer/Program.cs: ファイルからメッセージを取り出して処理する役割を担います。
//この実装は、単純なファイルベースのメッセージキューですが、スケーラビリティを考慮しています。
//大量のメッセージや高頻度のメッセージ処理には依然として制約がありますが、バッチ処理とファイルロックを導入することである程度のスケーラビリティを確保しています。

public static class MessageQueue
{
    private static readonly string queueDirectory = "MessageQueue";
    private static readonly object lockObject = new object();

    static MessageQueue()
    {
        if (!Directory.Exists(queueDirectory))
        {
            Directory.CreateDirectory(queueDirectory);
        }
    }

    public static async Task EnqueueAsync(string message)
    {
        string filePath = Path.Combine(queueDirectory, Guid.NewGuid().ToString() + ".txt");
        await File.WriteAllTextAsync(filePath, message);
    }

    public static async Task<IEnumerable<string>> DequeueBatchAsync(int batchSize)
    {
        var messages = new List<string>();

        lock (lockObject)
        {
            var files = Directory.GetFiles(queueDirectory);
            int count = Math.Min(files.Length, batchSize);

            for (int i = 0; i < count; i++)
            {
                var file = files[i];
                messages.Add(File.ReadAllText(file));
                File.Delete(file);
            }
        }

        return messages;
    }
}
