﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Shared;

//MessageQueue.cs: SQL Serverを使用してメッセージを保存し、ロックを使用してスレッドの安全性を確保しています。EnqueueAsyncメソッドでメッセージをキューに追加し、DequeueAllAsyncメソッドで未処理のメッセージを取得して処理済みとしてマークします。
//Producer/Program.cs: メッセージを生成してデータベースに追加する役割を担います。
//Consumer/Program.cs: データベースからメッセージを取り出して処理する役割を担います。
//この方法により、SQL Serverを使用したプロデューサーとコンシューマーのメッセージキューが実現できます。
//実際のプロジェクトでは、接続文字列の管理やエラーハンドリング、スケーラビリティの考慮が必要です。

public static class MessageQueue
{
    private static readonly string connectionString = "Server=YOUR_SERVER;Database=MessageQueueDB;Integrated Security=True;";

    public static async Task EnqueueAsync(string message)
    {
        using (var connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();
            var command = new SqlCommand("INSERT INTO Messages (Content) VALUES (@Content)", connection);
            command.Parameters.AddWithValue("@Content", message);
            await command.ExecuteNonQueryAsync();
        }
    }

    public static async Task<IEnumerable<string>> DequeueAllAsync()
    {
        var messages = new List<string>();

        using (var connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();
            var command = new SqlCommand("SELECT Id, Content FROM Messages WHERE Processed = 0", connection);
            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    messages.Add(reader["Content"].ToString());
                }
            }

            // Mark messages as processed
            var updateCommand = new SqlCommand("UPDATE Messages SET Processed = 1 WHERE Processed = 0", connection);
            await updateCommand.ExecuteNonQueryAsync();
        }

        return messages;
    }
}
