﻿export function initializeMonacoEditor(editorId, initialValue, dotnetHelper) {

    //require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.28.1/min/vs' } });
    require.config({
        paths: {
            "vs": "/monaco/min/vs"
        }
    });

    require(['vs/editor/editor.main'], function () {

        const editorElement = document.getElementById(editorId);

        if (editorElement) {

            let monacoOptions = {
                value: initialValue,
                language: 'markdown',
                automaticLayout: true,
                minimap: { enabled: false }
            }
            window.monacoEditor = monaco.editor.create(document.getElementById(editorId), monacoOptions);

            // リアルタイムのコンテンツ変更リスナーを設定します
            window.monacoEditor.onDidChangeModelContent(function () {
                const content = window.monacoEditor.getValue();
                dotnetHelper.invokeMethodAsync('UpdatePreview', content);
            });

            // Markdown 用の補完機能を設定します
            monaco.languages.registerCompletionItemProvider('markdown', {
                provideCompletionItems: () => {
                    return [
                        {
                            label: '## Header',
                            kind: monaco.languages.CompletionItemKind.Text,
                            insertText: '## ${1:Header}',
                            detail: 'Insert a level 2 header'
                        },
                        {
                            label: '- List Item',
                            kind: monaco.languages.CompletionItemKind.Text,
                            insertText: '- ${1:Item}',
                            detail: 'Insert a list item'
                        }
                    ];
                }
            });
        }
    });
};

//window.getMonacoEditorValue = (editorId) => {
//    return window.monacoEditor.getValue();
//};

//window.onEditorContentChanged = (editorId, initialValue, dotnetHelper) => {
//    if (window.monacoEditor) {
//        window.monacoEditor.onDidChangeModelContent(function () {
//            const content = window.monacoEditor.getValue();
//            dotnetHelper.invokeMethodAsync('UpdatePreview', content);
//        });
//    }
//};