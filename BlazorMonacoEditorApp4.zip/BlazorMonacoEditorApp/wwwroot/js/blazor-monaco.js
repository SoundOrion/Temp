﻿export function initializeMonacoEditor(editorId, initialValue, dotnetHelper) {

    //require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.28.1/min/vs' } });
    require.config({
        paths: {
            "vs": "/monaco/min/vs"
        }
    });

    require(['vs/editor/editor.main'], function () {

        const editorElement = document.getElementById(editorId);

        if (editorElement) {

            //組み込みテーマの一覧
            //vs - デフォルトの明るいテーマ
            //vs-dark - ダークテーマ
            //hc-black - 高コントラストの黒いテーマ

            let monacoOptions = {
                value: initialValue,
                language: 'markdown',
                theme: 'hc-black',
                automaticLayout: true,
                minimap: { enabled: false }
            }
            window.monacoEditor = monaco.editor.create(document.getElementById(editorId), monacoOptions);

            // リアルタイムのコンテンツ変更リスナーを設定します
            window.monacoEditor.onDidChangeModelContent(function () {
                const content = window.monacoEditor.getValue();
                dotnetHelper.invokeMethodAsync('UpdatePreview', content);
            });

            // Markdown 用の補完機能を設定します
            monaco.languages.registerCompletionItemProvider('markdown', {
                provideCompletionItems: () => {
                    return [
                        {
                            label: '## Header',
                            kind: monaco.languages.CompletionItemKind.Text,
                            insertText: '## ${1:Header}',
                            detail: 'Insert a level 2 header'
                        },
                        {
                            label: '- List Item',
                            kind: monaco.languages.CompletionItemKind.Text,
                            insertText: '- ${1:Item}',
                            detail: 'Insert a list item'
                        }
                    ];
                }
            });
        }
    });
};

//window.getMonacoEditorValue = (editorId) => {
//    return window.monacoEditor.getValue();
//};

//window.onEditorContentChanged = (editorId, initialValue, dotnetHelper) => {
//    if (window.monacoEditor) {
//        window.monacoEditor.onDidChangeModelContent(function () {
//            const content = window.monacoEditor.getValue();
//            dotnetHelper.invokeMethodAsync('UpdatePreview', content);
//        });
//    }
//};

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        resizer.addEventListener('mousedown', function (e) {
//            document.addEventListener('mousemove', resize);
//            document.addEventListener('mouseup', stopResize);
//        });

//        function resize(e) {
//            const containerRect = container.getBoundingClientRect();
//            const newEditorWidth = e.clientX - containerRect.left;
//            const newPreviewWidth = containerRect.right - e.clientX;

//            if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                editor.style.flexBasis = newEditorWidth + 'px';
//                preview.style.flexBasis = newPreviewWidth + 'px';
//                resizer.style.right = newPreviewWidth + 'px';
//            }
//        }

//        function stopResize() {
//            document.removeEventListener('mousemove', resize);
//            document.removeEventListener('mouseup', stopResize);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();
//                    const newEditorWidth = e.clientX - containerRect.left;
//                    const newPreviewWidth = containerRect.right - e.clientX;

//                    if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.right = newPreviewWidth + 'px';
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;
//        let userSelectBackup = '';

//        // テキスト選択を無効にする関数
//        function disableTextSelection() {
//            userSelectBackup = document.body.style.userSelect;
//            document.body.style.userSelect = 'none';
//        }

//        // テキスト選択を有効に戻す関数
//        function enableTextSelection() {
//            document.body.style.userSelect = userSelectBackup;
//        }

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            disableTextSelection(); // テキスト選択を無効にする
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();
//                    const newEditorWidth = e.clientX - containerRect.left;
//                    const newPreviewWidth = containerRect.right - e.clientX;

//                    if (newEditorWidth > 50 && newPreviewWidth > 50) { // 最小幅を設定
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.right = newPreviewWidth + 'px';
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            enableTextSelection(); // テキスト選択を元に戻す
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}

//export function initializeResizable() {
//    const editor = document.getElementById('editor');
//    const preview = document.getElementById('preview');
//    const container = document.querySelector('.resizable-container');
//    const resizer = document.querySelector('.resizer');

//    if (editor && preview && container && resizer) {
//        let isResizing = false;
//        let userSelectBackup = '';

//        function disableTextSelection() {
//            userSelectBackup = document.body.style.userSelect;
//            document.body.style.userSelect = 'none';
//        }

//        function enableTextSelection() {
//            document.body.style.userSelect = userSelectBackup;
//        }

//        resizer.addEventListener('mousedown', function (e) {
//            isResizing = true;
//            disableTextSelection(); // テキスト選択を無効にする
//            document.addEventListener('mousemove', onMouseMove);
//            document.addEventListener('mouseup', onMouseUp);
//        });

//        function onMouseMove(e) {
//            if (isResizing) {
//                requestAnimationFrame(() => {
//                    const containerRect = container.getBoundingClientRect();

//                    // 現在のエディタとプレビューの幅
//                    const editorWidth = editor.getBoundingClientRect().width;
//                    const previewWidth = preview.getBoundingClientRect().width;

//                    // 最小幅の設定
//                    const minWidth = 50;

//                    // 新しい幅の計算
//                    let newEditorWidth = e.clientX - containerRect.left;
//                    let newPreviewWidth = containerRect.right - e.clientX;

//                    // 幅が最小幅以上であり、かつコンテナの幅を超えないように制約
//                    if (newEditorWidth >= minWidth && newPreviewWidth >= minWidth) {
//                        editor.style.flexBasis = newEditorWidth + 'px';
//                        preview.style.flexBasis = newPreviewWidth + 'px';
//                        resizer.style.left = newEditorWidth + 'px'; // resizerの位置を更新
//                    }
//                });
//            }
//        }

//        function onMouseUp() {
//            isResizing = false;
//            enableTextSelection(); // テキスト選択を元に戻す
//            document.removeEventListener('mousemove', onMouseMove);
//            document.removeEventListener('mouseup', onMouseUp);
//        }
//    }
//}



export function initializeResizable() {
    const editor = document.getElementById('editor');
    const preview = document.getElementById('preview');
    const container = document.querySelector('.resizable-container');
    const resizer = document.querySelector('.resizer');

    if (editor && preview && container && resizer) {
        let isResizing = false;
        let userSelectBackup = '';

        function disableTextSelection() {
            userSelectBackup = document.body.style.userSelect;
            document.body.style.userSelect = 'none';
        }

        function enableTextSelection() {
            document.body.style.userSelect = userSelectBackup;
        }

        resizer.addEventListener('mousedown', function (e) {
            isResizing = true;
            disableTextSelection(); // テキスト選択を無効にする
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        function onMouseMove(e) {
            if (isResizing) {
                requestAnimationFrame(() => {
                    const containerRect = container.getBoundingClientRect();

                    // コンテナの幅を取得
                    const containerWidth = containerRect.width;

                    // 新しい幅の計算
                    const minWidth = 50;
                    let newEditorWidth = e.clientX - containerRect.left;
                    let newPreviewWidth = containerRect.right - e.clientX;

                    // エディタとプレビューの幅が最小幅以上であり、かつコンテナの幅を超えないように制約
                    if (newEditorWidth >= minWidth && newPreviewWidth >= minWidth && newEditorWidth + newPreviewWidth <= containerWidth) {
                        resizer.style.left = newEditorWidth + 'px'; // resizerの位置を更新
                        editor.style.flexBasis = newEditorWidth + 'px';
                        preview.style.flexBasis = newPreviewWidth + 'px';                 
                    }
                });
            }
        }

        function onMouseUp() {
            isResizing = false;
            enableTextSelection(); // テキスト選択を元に戻す
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
    }
}
