﻿using Orleans;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class ProcessingGrain : Grain, IProcessingGrain
{
    public Task ProcessBatchAsync(List<(int, string)> batch)
    {
        foreach (var (id, content) in batch)
        {
            if (content.Contains("example keyword"))
            {
                Console.WriteLine($"ID={id}: キーワードが含まれています。処理を行います。");
                // 処理の実装
            }
            else
            {
                Console.WriteLine($"ID={id}: キーワードは含まれていません。");
            }
        }
        return Task.CompletedTask;
    }
}
