﻿using Orleans;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IProcessingGrain : IGrainWithIntegerKey
{
    Task ProcessBatchAsync(List<(int, string)> batch);
}
