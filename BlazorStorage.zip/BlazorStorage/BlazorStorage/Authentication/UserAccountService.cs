﻿namespace BlazorStorage.Authentication;

public class UserAccountService
{
    private List<UserAccount> _users;

    public UserAccountService()
    {
        _users =
        [
            new() { UserName = "admin", Password = "admin", Role = "Administrator" },
            new() { UserName = "administrator", Password = "administrator", Role = "Administrator" },
        ];
    }

    /// <summary>
    /// UserAccount? means that the method GetByUserName can return a valid UserAccount object or null. 
    /// </summary>
    /// <param name="userName"></param>
    /// <returns></returns>
    public UserAccount? GetByUserName(string userName)
    {
        return _users.FirstOrDefault(x => x.UserName == userName);
    }
}
