﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static BlockingCollection<List<(int, string)>> queue = new BlockingCollection<List<(int, string)>>();
    static int batchSize = 10; // バッチサイズを指定

    static async Task Main()
    {
        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int pollingInterval = 60000; // 60秒ごとにポーリング

        Task producerTask = Task.Run(() => Producer(connectionString, tableName, pollingInterval));
        Task consumerTask = Task.Run(() => Consumer());

        await Task.WhenAll(producerTask, consumerTask);
    }

    static async Task Producer(string connectionString, string tableName, int pollingInterval)
    {
        while (true)
        {
            try
            {
                await CheckDatabaseAsync(connectionString, tableName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task CheckDatabaseAsync(string connectionString, string tableName)
    {
        string query = $"SELECT TOP (@BatchSize) * FROM {tableName} WHERE Processed = 0";
        var batch = new List<(int, string)>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@BatchSize", batchSize);

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int id = reader.GetInt32(0);
                        string content = reader.GetString(1);
                        batch.Add((id, content));
                    }
                }
            }
        }

        if (batch.Count > 0)
        {
            queue.Add(batch);

            foreach (var (id, _) in batch)
            {
                await MarkRecordAsProcessedAsync(connectionString, tableName, id);
            }
        }
    }

    private static async Task MarkRecordAsProcessedAsync(string connectionString, string tableName, int id)
    {
        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                await command.ExecuteNonQueryAsync();
            }
        }
    }

    static void Consumer()
    {
        foreach (var batch in queue.GetConsumingEnumerable())
        {
            ProcessBatch(batch);
        }
    }

    private static void ProcessBatch(List<(int, string)> batch)
    {
        foreach (var (id, content) in batch)
        {
            // レコードの内容に応じた処理を実装
            if (content.Contains("example keyword"))
            {
                Console.WriteLine($"ID={id}: キーワードが含まれています。処理を行います。");
                // 処理の実装
            }
            else
            {
                Console.WriteLine($"ID={id}: キーワードは含まれていません。");
            }
        }
    }
}
