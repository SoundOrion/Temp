﻿using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using GrainInterfaces;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;

public class Program
{
    private static BlockingCollection<List<(int, string)>> queue = new BlockingCollection<List<(int, string)>>();

    static async Task Main(string[] args)
    {
        var client = await StartClientAsync();

        var producerTask = Task.Run(() => ProduceAsync(client));
        var consumerTask = Task.Run(() => ConsumeAsync(client));

        await Task.WhenAll(producerTask, consumerTask);
    }

    private static async Task<IClusterClient> StartClientAsync()
    {
        var builder = Host.CreateDefaultBuilder()
    .UseOrleansClient(builder =>
    {
        builder.UseLocalhostClustering();
        builder.Configure<ClusterOptions>(options =>
        {
            options.ClusterId = "dev";
            options.ServiceId = "OrleansSampleApp";
        });
    })
    .ConfigureLogging(logging => logging.AddConsole())
    .UseConsoleLifetime();

        using IHost host = builder.Build();
        await host.StartAsync();

        IClusterClient client = host.Services.GetRequiredService<IClusterClient>();

        return client;
    }

    private static async Task ProduceAsync(IClusterClient client)
    {
        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int batchSize = 10; // バッチサイズを指定
        int pollingInterval = 60000; // 60秒ごとにポーリング

        while (true)
        {
            try
            {
                var batch = await CheckDatabaseAsync(connectionString, tableName, batchSize);
                if (batch.Count > 0)
                {
                    queue.Add(batch);
                    await MarkRecordsAsProcessedAsync(connectionString, tableName, batch);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task ConsumeAsync(IClusterClient client)
    {
        var processingGrain = client.GetGrain<IProcessingGrain>(0);

        foreach (var batch in queue.GetConsumingEnumerable())
        {
            await processingGrain.ProcessBatchAsync(batch);
        }
    }

    private static async Task<List<(int, string)>> CheckDatabaseAsync(string connectionString, string tableName, int batchSize)
    {
        string query = $"SELECT TOP (@BatchSize) * FROM {tableName} WHERE Processed = 0";
        var batch = new List<(int, string)>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@BatchSize", batchSize);

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int id = reader.GetInt32(0);
                        string content = reader.GetString(1);
                        batch.Add((id, content));
                    }
                }
            }
        }

        return batch;
    }

    private static async Task MarkRecordsAsProcessedAsync(string connectionString, string tableName, List<(int, string)> batch)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            foreach (var (id, _) in batch)
            {
                string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
