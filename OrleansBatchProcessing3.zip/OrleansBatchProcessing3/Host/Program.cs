﻿//using Microsoft.Extensions.Hosting;
//using Microsoft.Extensions.Logging;

//IHostBuilder builder = Host.CreateDefaultBuilder(args)
//    .UseOrleans(silo =>
//    {
//        silo.UseLocalhostClustering()
//            .ConfigureLogging(logging => logging.AddConsole());
//    })
//    .UseConsoleLifetime();

//using IHost host = builder.Build();

//await host.RunAsync();

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using System;
using System.Threading.Tasks;

/// <summary>
/// サイロを作成する
/// </summary>
public class Program
{
    public static async Task Main(string[] args)
    {
        var host = await StartSilo();
        Console.WriteLine("Press Enter to terminate...");
        Console.ReadLine();
        await host.StopAsync();
    }

    private static async Task<IHost> StartSilo()
    {
        var host = Host.CreateDefaultBuilder()
            .UseOrleans(builder =>
            {
                builder.UseLocalhostClustering();
                builder.Configure<ClusterOptions>(options =>
                {
                    options.ClusterId = "dev";
                    options.ServiceId = "OrleansSampleApp";
                });
                builder.ConfigureLogging(logging => logging.AddConsole());
            })
            .Build();

        await host.StartAsync();
        return host;
    }

    //private static async Task<IHost> StartSilo()
    //{
    //    //    IHostBuilder builder = Host.CreateDefaultBuilder(args)
    //    //.UseOrleans(silo =>
    //    //{
    //    //    silo.UseLocalhostClustering()
    //    //        .ConfigureLogging(logging => logging.AddConsole());
    //    //})
    //    //.UseConsoleLifetime();

    //    //    using IHost host = builder.Build();

    //    //    await host.RunAsync();



    //    IHostBuilder builder = Host.CreateDefaultBuilder()
    //.UseOrleans(silo =>
    //{
    //    silo.UseLocalhostClustering();
    //    silo.Configure<ClusterOptions>(options =>
    //    {
    //        options.ClusterId = "dev";
    //        options.ServiceId = "OrleansSampleApp";
    //    });
    //    silo.ConfigureLogging(logging => logging.AddConsole());
    //})
    //.Build();

    //    using IHost host = builder.Build();
    //    await host.StartAsync();
    //    return host;

    //}
}


//処理の流れ
//クライアント（プロデューサー）:

//ProduceAsync メソッドでデータベースを定期的にポーリングし、新しいデータをバッチで取得します。
//取得したデータバッチを BlockingCollection に追加します。
//データベース内のレコードを処理済みとしてマークします。
//BlockingCollection:

//キューとして機能し、プロデューサーから受け取ったデータバッチをバッファリングします。
//コンシューマーはこのキューからデータバッチを取得します。
//アクター（コンシューマー）:

//ConsumeAsync メソッドで BlockingCollection からデータバッチを取り出し、アクターに処理を依頼します。
//ProcessBatchAsync メソッドでデータバッチを処理します。
//この実装により、BlockingCollectionを使用してプロデューサーとコンシューマー間のデータをバッファリングすることで、
//プロデューサーがデータを生成する速度とコンシューマーがデータを処理する速度を独立させることができます。これにより、システム全体の柔軟性と効率が向上します。