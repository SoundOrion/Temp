﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

class Program
{
    const string ServiceBusConnectionString = "your_service_bus_connection_string_here";
    const string QueueName = "your_queue_name_here";
    static IQueueClient queueClient;

    static async Task Main()
    {
        queueClient = new QueueClient(ServiceBusConnectionString, QueueName);
        var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
        {
            MaxConcurrentCalls = 1,
            AutoComplete = false
        };

        queueClient.RegisterMessageHandler(ProcessMessagesAsync, messageHandlerOptions);

        Console.WriteLine("キューのメッセージ処理を開始します。終了するには[Enter]キーを押してください。");
        Console.ReadLine();

        await queueClient.CloseAsync();
    }

    static async Task ProcessMessagesAsync(Message message, CancellationToken token)
    {
        string messageBody = Encoding.UTF8.GetString(message.Body);
        string[] parts = messageBody.Split(':');
        int id = int.Parse(parts[0]);
        string content = parts[1];

        Console.WriteLine($"メッセージを処理中: ID={id}, Content={content}");

        // メッセージの内容に応じた処理を実装
        ProcessRecord(id, content);

        await queueClient.CompleteAsync(message.SystemProperties.LockToken);
    }

    private static void ProcessRecord(int id, string content)
    {
        // ここにレコードの内容に応じた処理を実装
        if (content.Contains("example keyword"))
        {
            Console.WriteLine("キーワードが含まれています。処理を行います。");
            // 処理の実装
        }
        else
        {
            Console.WriteLine("キーワードは含まれていません。");
        }
    }

    static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
    {
        Console.WriteLine($"メッセージハンドラでエラーが発生しました: {exceptionReceivedEventArgs.Exception}.");
        return Task.CompletedTask;
    }
}
