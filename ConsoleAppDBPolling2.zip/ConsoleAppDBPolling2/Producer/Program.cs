﻿using System;
using System.Data.SqlClient;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

class Program
{
    const string ServiceBusConnectionString = "your_service_bus_connection_string_here";
    const string QueueName = "your_queue_name_here";
    static IQueueClient queueClient;

    static async Task Main()
    {
        queueClient = new QueueClient(ServiceBusConnectionString, QueueName);

        string connectionString = "your_sql_connection_string_here";
        string tableName = "your_table_name_here";
        int pollingInterval = 60000; // 60秒ごとにポーリング

        while (true)
        {
            try
            {
                await CheckDatabaseAsync(connectionString, tableName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            // 次のチェックまで待機
            await Task.Delay(pollingInterval);
        }
    }

    private static async Task CheckDatabaseAsync(string connectionString, string tableName)
    {
        string query = $"SELECT * FROM {tableName} WHERE Processed = 0";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int id = reader.GetInt32(0);
                        string content = reader.GetString(1);

                        Console.WriteLine($"レコードをキューに送信: ID={id}, Content={content}");

                        var message = new Message(Encoding.UTF8.GetBytes($"{id}:{content}"));
                        await queueClient.SendAsync(message);

                        // レコードを処理済みに更新
                        await MarkRecordAsProcessedAsync(connectionString, tableName, id);
                    }
                }
            }
        }
    }

    private static async Task MarkRecordAsProcessedAsync(string connectionString, string tableName, int id)
    {
        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
