﻿using System;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

//ポーリングループ:

//while (true) ループで定期的にデータベースをチェック。pollingIntervalで待機時間を指定（この例では10秒）。
//データベースのチェック:

//CheckDatabaseAsyncメソッドでデータベースに接続し、Processed列が0のレコードを取得。
//レコードの処理:

//ProcessRecordメソッドでレコードの内容に応じた処理を実装。
//例として、特定のキーワードが含まれているかをチェックし、含まれている場合には特定の処理を実行。
//レコードの更新:

//MarkRecordAsProcessedAsyncメソッドで、処理が完了したレコードのProcessedフラグを1に更新。
//このプログラムを実行すると、指定したデータベースのテーブルを定期的にチェックし、処理が必要なレコードを見つけて処理を行い、処理済みのレコードを更新します。

class Program
{
    static async Task Main()
    {
        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int pollingInterval = 10000; // 10秒ごとにポーリング

        while (true)
        {
            try
            {
                await CheckDatabaseAsync(connectionString, tableName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            // 次のチェックまで待機
            await Task.Delay(pollingInterval);
        }
    }

    private static async Task CheckDatabaseAsync(string connectionString, string tableName)
    {
        string query = $"SELECT * FROM {tableName} WHERE Processed = 0";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        // ここでレコードの内容を処理
                        int id = reader.GetInt32(0); // 例として最初の列をIDと仮定
                        string content = reader.GetString(1); // 例として2番目の列を内容と仮定

                        Console.WriteLine($"レコードを処理中: ID={id}, Content={content}");

                        // レコードの内容に応じた処理を行う
                        ProcessRecord(id, content);

                        // 処理が完了したら、Processedフラグを更新
                        await MarkRecordAsProcessedAsync(connectionString, tableName, id);
                    }
                }
            }
        }
    }

    private static void ProcessRecord(int id, string content)
    {
        // ここにレコードの内容に応じた処理を実装
        if (content.Contains("example keyword"))
        {
            Console.WriteLine("キーワードが含まれています。処理を行います。");
            // 処理の実装
        }
        else
        {
            Console.WriteLine("キーワードは含まれていません。");
        }
    }

    private static async Task MarkRecordAsProcessedAsync(string connectionString, string tableName, int id)
    {
        string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
