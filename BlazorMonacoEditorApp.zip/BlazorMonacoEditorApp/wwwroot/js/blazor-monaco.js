﻿window.initializeMonacoEditor = (editorId, initialValue) => {

    //require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.28.1/min/vs' } });
    require.config({
        paths: {
            "vs": "/monaco/min/vs"
        }
    });

    require(['vs/editor/editor.main'], function () {

        let monacoOptions = {
            value: initialValue,
            language: 'markdown',
            automaticLayout: true,
            minimap: { enabled: false }
        }

        window.monacoEditor = monaco.editor.create(document.getElementById(editorId), monacoOptions);
    });
};

window.getMonacoEditorValue = (editorId) => {
    return window.monacoEditor.getValue();
};

window.onEditorContentChanged = (editorId, initialValue, dotnetHelper) => {
    if (window.monacoEditor) {
        window.monacoEditor.onDidChangeModelContent(function () {
            const content = window.monacoEditor.getValue();
            dotnetHelper.invokeMethodAsync('UpdatePreview', content);
        });
    }
};