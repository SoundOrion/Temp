﻿using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

public class Program
{
    static async Task Main(string[] args)
    {
        using (var client = await StartClientAsync())
        {
            await ProduceAndConsumeAsync(client);
        }
    }

    private static async Task<IClusterClient> StartClientAsync()
    {
        var client = new ClientBuilder()
            .UseLocalhostClustering()
            .Configure<ClusterOptions>(options =>
            {
                options.ClusterId = "dev";
                options.ServiceId = "OrleansSampleApp";
            })
            .ConfigureLogging(logging => logging.AddConsole())
            .Build();

        await client.Connect();
        Console.WriteLine("Client successfully connected to silo host \n");
        return client;
    }

    private static async Task ProduceAndConsumeAsync(IClusterClient client)
    {
        var processingGrain = client.GetGrain<IProcessingGrain>(0);

        string connectionString = "your_connection_string_here";
        string tableName = "your_table_name_here";
        int batchSize = 10; // バッチサイズを指定
        int pollingInterval = 60000; // 60秒ごとにポーリング

        while (true)
        {
            try
            {
                var batch = await CheckDatabaseAsync(connectionString, tableName, batchSize);
                if (batch.Count > 0)
                {
                    await processingGrain.ProcessBatchAsync(batch);
                    await MarkRecordsAsProcessedAsync(connectionString, tableName, batch);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"データベースのチェック中にエラーが発生しました: {ex.Message}");
            }

            await Task.Delay(pollingInterval);
        }
    }

    private static async Task<List<(int, string)>> CheckDatabaseAsync(string connectionString, string tableName, int batchSize)
    {
        string query = $"SELECT TOP (@BatchSize) * FROM {tableName} WHERE Processed = 0";
        var batch = new List<(int, string)>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@BatchSize", batchSize);

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int id = reader.GetInt32(0);
                        string content = reader.GetString(1);
                        batch.Add((id, content));
                    }
                }
            }
        }

        return batch;
    }

    private static async Task MarkRecordsAsProcessedAsync(string connectionString, string tableName, List<(int, string)> batch)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            await connection.OpenAsync();

            foreach (var (id, _) in batch)
            {
                string updateQuery = $"UPDATE {tableName} SET Processed = 1 WHERE ID = @ID";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }
    }
}

//コードの説明
//アクターインターフェース:

//IProcessingGrain は、バッチ処理を行うためのメソッド ProcessBatchAsync を定義します。
//アクターの実装:

//ProcessingGrain クラスは、バッチ内のレコードを処理するロジックを実装します。
//Orleansホストの設定:

//StartSilo メソッドでOrleansホストを設定し、ローカルホストクラスタリングを使用します。
//クライアントの実装:

//StartClientAsync メソッドでOrleansクライアントを起動し、ホストに接続します。
//ProduceAndConsumeAsync メソッドでデータベースをポーリングし、変更されたレコードをバッチサイズごとに取得してアクターに処理を依頼します。
//この実装により、Orleansの仮想アクターモデルを使用してスケーラブルで効率的なバッチ処理システムを構築できます。Orleansのアクターはステートフルであるため、状態を管理しやすく、スケーリングも容易です。


//BlockingCollectionを使った実装とMicrosoft Orleansを使った実装のどちらが優れているかは、システムの要件や特性に依存します。それぞれの利点と欠点を比較してみましょう。

//BlockingCollectionを使った実装の利点と欠点
//利点
//シンプルで分かりやすい:

//.NET標準ライブラリの一部であり、使い方が直感的です。
//実装が比較的簡単で、依存関係が少ない。
//リアルタイム処理:

//データがキューに追加されると、即座に処理が開始されます。
//低いレイテンシー:

//キューにデータが追加されると同時に処理が開始されるため、レイテンシーが低くなります。
//欠点
//スケーラビリティの制限:

//単一のプロセスで実行されるため、スケーラビリティに限界があります。
//高負荷なシナリオや分散システムには不向きです。
//耐障害性の欠如:

//プロセスがクラッシュすると、キューのデータは失われる可能性があります。
//データの永続性を確保するためには、追加の実装が必要です。
//Microsoft Orleansを使った実装の利点と欠点
//利点
//スケーラビリティ:

//クラウド環境や分散システムでの運用に適しており、容易にスケールアウトが可能です。
//アクター（Grain）が複数のノードに分散して実行されるため、高いスループットを実現できます。
//耐障害性:

//Orleansは分散システムとして設計されており、ノード障害やネットワーク障害に対する耐性があります。
//状態の永続化（Persistence）やリマインダー（Reminders）機能により、データの保全性が高いです。
//柔軟性:

//アクターごとに異なる処理を実装できるため、複雑なビジネスロジックを簡単に管理できます。
//欠点
//複雑さ:

//学習曲線があり、セットアップや管理がやや複雑です。
//Orleansの概念やライフサイクルを理解するための時間が必要です。
//オーバーヘッド:

//システムが分散しているため、ネットワークオーバーヘッドや分散システムの管理コストが発生します。
//単一プロセスでの運用よりもリソース消費が高い可能性があります。
//どちらが優れているか？
//BlockingCollectionが適している場合
//システムが単一プロセスで動作し、シンプルなキュー処理を必要とする場合。
//高いスループットやスケーラビリティが要求されない小規模なアプリケーション。
//シンプルで迅速な実装が求められる場合。
//Microsoft Orleansが適している場合
//システムがスケーラブルで高い可用性を必要とする場合。
//複数のノードに分散して動作させる必要がある場合。
//複雑なビジネスロジックを管理し、耐障害性が求められる場合。
//結論
//システムの要件や運用環境に応じて、どちらのアプローチが適しているかを判断する必要があります。
//小規模でシンプルな要件にはBlockingCollectionを、スケーラブルで高可用性が求められるシステムにはMicrosoft Orleansを使用するのが良いでしょう。