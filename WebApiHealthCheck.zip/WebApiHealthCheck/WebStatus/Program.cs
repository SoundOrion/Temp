using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddHealthChecks()
    .AddCheck("self", () => HealthCheckResult.Healthy());
//builder.Services.AddHealthChecks();

builder.Services
    .AddHealthChecksUI()
    .AddInMemoryStorage();

//builder.Services.AddHealthChecksUI(setupSettings: settings =>
//{
//    var healthCheckName = "aaaa";
//    var healthCheckUri = "https://localhost:7295/hc";

//    settings
//        .DisableDatabaseMigrations()
//        .AddHealthCheckEndpoint(name: healthCheckName, uri: healthCheckUri);
//        //.AddWebhookNotification(name: webhookName, uri: webhookUri, payload: webhookPayload,
//        //    restorePayload: webhookRestorePayload)
//        //.SetEvaluationTimeInSeconds(evaluationTimeInSeconds)
//        //.SetMinimumSecondsBetweenFailureNotifications(minimumSeconds);
//}).AddInMemoryStorage();

var app = builder.Build();

var pathBase = "";// Configuration["PATH_BASE"];
if (!string.IsNullOrEmpty(pathBase))
{
    app.UsePathBase(pathBase);
}

app.UseHealthChecksUI(config =>
{
    config.ResourcesPath = string.IsNullOrEmpty(pathBase) ? "/ui/resources" : $"{pathBase}/ui/resources";
    config.UIPath = "/hc-ui";
});

//// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
//    app.UseExceptionHandler("/Error");
//}
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();

app.UseRouting();
app.MapDefaultControllerRoute();
app.MapHealthChecks("/liveness", new HealthCheckOptions
{
    Predicate = r => r.Name.Contains("self")
});

//app.UseAuthorization();

//app.MapRazorPages();

app.Run();



//https://dev.to/krusty93/implementing-health-checks-pt1-aspnet-core-6-configuration-6gp


//-HealthChecksUI__HealthChecks__0__Name = WebMVC HTTP Check
//      - HealthChecksUI__HealthChecks__0__Uri=http://webmvc/hc