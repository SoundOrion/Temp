using Microsoft.AspNetCore.Authentication;
using Microsoft.OpenApi.Models;
using WebApi;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c=>
{
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme",
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer"
    });

    // Bearer�g�[�N����K�v�Ƃ��邽�߂̃Z�L�����e�B�v����ǉ�
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                new string[] { }
            }
        });
});


// �i�_�~�[�j�F�؂�ݒ�
builder.Services.AddAuthentication("Bearer")
    .AddScheme<AuthenticationSchemeOptions, DummyAuthenticationHandler>("Bearer", options => { });


//// �F��ݒ�
//builder.Services.AddAuthorization(options =>
//{
//    options.AddPolicy("ApiAccess", policy =>
//    {
//        policy.RequireAuthenticatedUser();
//    });
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseMiddleware<ImageAccessMiddleware>();

// �F�؂���єF�~�h���E�F�A��ǉ�
app.UseAuthentication();
app.UseAuthorization();


app.UseStaticFiles();

app.MapControllers();

app.Run();
